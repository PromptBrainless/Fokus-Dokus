//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cw8bJy41.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DMfgm5lP.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DMfgm5lP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dqm524xD.js"]
	}
} });
//#endregion
export { tsrStartManifest };
