import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as SkipForward, c as Pause, d as BookOpen, i as Swords, l as Orbit, n as Volume2, o as Shield, s as Play, t as VolumeX, u as Footprints } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BPZpD_vw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Karten der Regel, vor jedem Ausgleich. Fähigkeiten gelten in der Basis nicht. */
var BASIS_HEROES = [
	{
		id: "brecher",
		name: "Brecher",
		line: "Schwerer Treffer",
		kraft: 8,
		schutz: 5,
		bewegung: 2,
		kontrolle: 2,
		tempo: 3
	},
	{
		id: "laeuferin",
		name: "Läuferin",
		line: "Durchgang",
		kraft: 3,
		schutz: 3,
		bewegung: 8,
		kontrolle: 5,
		tempo: 8
	},
	{
		id: "archivar",
		name: "Archivar",
		line: "Speichern",
		kraft: 3,
		schutz: 4,
		bewegung: 4,
		kontrolle: 9,
		tempo: 4
	},
	{
		id: "waechter",
		name: "Wächter",
		line: "Standhalten",
		kraft: 4,
		schutz: 8,
		bewegung: 2,
		kontrolle: 5,
		tempo: 2
	},
	{
		id: "jaeger",
		name: "Jäger",
		line: "Verfolgen",
		kraft: 6,
		schutz: 3,
		bewegung: 5,
		kontrolle: 4,
		tempo: 7
	}
];
function basisHero(id) {
	const found = BASIS_HEROES.find((hero) => hero.id === id);
	if (!found) throw new Error(`Unbekannte Karte: ${id}`);
	return found;
}
function bonus$1(value) {
	if (value <= 2) return 0;
	if (value <= 4) return 1;
	if (value <= 6) return 2;
	if (value <= 8) return 3;
	return 4;
}
function basisPools(hero) {
	return {
		body: 12 + hero.schutz,
		energy: Math.max(3, Math.min(8, 4 + Math.floor(hero.bewegung / 3))),
		bruch: 4 + Math.floor(hero.schutz / 2)
	};
}
function roll$1(state) {
	state.seed = state.seed + 1831565813 | 0;
	let t = Math.imul(state.seed ^ state.seed >>> 15, 1 | state.seed);
	t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
	return ((t ^ t >>> 14) >>> 0) / 4294967296;
}
function d6$1(state) {
	return 1 + Math.floor(roll$1(state) * 6);
}
function other$1(side) {
	return side === "A" ? "B" : "A";
}
function nameOf(state, side) {
	return basisHero(state.fighters[side].heroId).name;
}
function note$1(state, line) {
	state.log.push(line);
}
function isOpen$1(f) {
	return f.bruch >= Math.ceil(f.bruchMax / 2);
}
function createBasis(heroA, heroB, seed = 1) {
	const make = (side, id) => {
		const pools = basisPools(basisHero(id));
		return {
			side,
			heroId: id,
			body: pools.body,
			bodyMax: pools.body,
			energy: 2,
			energyMax: pools.energy,
			bruch: 0,
			bruchMax: pools.bruch,
			collapse: false
		};
	};
	return {
		round: 0,
		fighters: {
			A: make("A", heroA),
			B: make("B", heroB)
		},
		log: [],
		winner: null,
		winReason: null,
		over: false,
		seed,
		roundCap: 16
	};
}
function beginBasisRound(input) {
	const state = structuredClone(input);
	if (state.over) return state;
	state.round += 1;
	const bits = [];
	for (const side of ["A", "B"]) {
		const f = state.fighters[side];
		const before = f.energy;
		f.energy = Math.min(f.energyMax, f.energy + 2);
		bits.push(`${nameOf(state, side)} +${f.energy - before} Energie`);
	}
	note$1(state, `Runde ${state.round}. ${bits.join(" · ")}.`);
	return state;
}
function actionTempo$1(action) {
	if (action === "block") return -1;
	if (action === "ausweichen") return 2;
	return 0;
}
function basisActionValue(hero, choice) {
	return hero.tempo + actionTempo$1(choice.action) + Math.max(0, choice.energy);
}
function clampChoice(f, choice) {
	if (choice.action === "ausweichen") return {
		action: "ausweichen",
		energy: 0
	};
	const cap = choice.action === "block" ? 1 : 3;
	return {
		action: choice.action,
		energy: Math.max(0, Math.min(cap, choice.energy, f.energy))
	};
}
function orderSides$1(state, choices) {
	const score = (side) => basisActionValue(basisHero(state.fighters[side].heroId), choices[side]);
	const pair = ["A", "B"];
	const dice = {
		A: d6$1(state),
		B: d6$1(state)
	};
	pair.sort((a, b) => {
		const va = score(a);
		const vb = score(b);
		if (va !== vb) return vb - va;
		if (choices[a].energy !== choices[b].energy) return choices[a].energy - choices[b].energy;
		const ta = basisHero(state.fighters[a].heroId).tempo;
		const tb = basisHero(state.fighters[b].heroId).tempo;
		if (ta !== tb) return tb - ta;
		if (state.fighters[a].body !== state.fighters[b].body) return state.fighters[a].body - state.fighters[b].body;
		return dice[b] - dice[a];
	});
	return [pair[0], pair[1]];
}
function label$1(action) {
	if (action === "kampf") return "Kampf";
	if (action === "block") return "Block";
	return "Ausweichen";
}
function finish(state, winner, reason) {
	state.over = true;
	state.winner = winner;
	state.winReason = reason;
}
function gainBruch$1(state, f, amount) {
	if (amount <= 0 || f.body <= 0) return 0;
	const before = f.bruch;
	f.bruch = Math.min(f.bruchMax, f.bruch + amount);
	if (f.bruch >= f.bruchMax) f.collapse = true;
	return f.bruch - before;
}
function strike(state, attacker, choices) {
	const a = state.fighters[attacker];
	const defender = other$1(attacker);
	const d = state.fighters[defender];
	const aHero = basisHero(a.heroId);
	const dHero = basisHero(d.heroId);
	const plan = choices[attacker];
	const spent = Math.min(a.energy, plan.energy);
	a.energy -= spent;
	const attack = bonus$1(aHero.kraft) + spent;
	const defense = 2 + bonus$1(dHero.schutz) + bonus$1(dHero.bewegung);
	const die = d6$1(state);
	const diceNote = `Würfel ${die}. Angriff ${attack} gegen Verteidigung ${defense}.`;
	if (die + attack < defense) {
		const line = `${aHero.name} verfehlt ${dHero.name}. ${diceNote}`;
		note$1(state, line);
		if (choices[defender].action === "ausweichen") note$1(state, `${dHero.name} muss nicht ausweichen.`);
		return line;
	}
	const energyRaw = spent >= 3 ? 2 : spent >= 1 ? 1 : 0;
	let bruchMod = spent >= 2 ? 1 : 0;
	let end = Math.max(1, bonus$1(aHero.kraft) + energyRaw - bonus$1(dHero.schutz));
	const bits = [`Roh ${bonus$1(aHero.kraft) + energyRaw}`, `nach Schutzbonus ${end}`];
	if (choices[defender].action === "block") {
		const cut = choices[defender].energy >= 1 ? 4 : 3;
		end = Math.max(0, end - cut);
		bruchMod -= 1;
		bits.push(`Block −${cut}`);
	}
	if (isOpen$1(d)) {
		end += 1;
		bruchMod += 1;
		bits.push("Offen +1");
	}
	if (die === 6) {
		end *= 2;
		bruchMod += 1;
		bits.push("Kritisch");
	}
	if (choices[defender].action === "ausweichen") {
		if (d.energy >= 2) {
			d.energy -= 2;
			end = Math.max(0, end - 2);
			bits.push("Ausweichen −2");
		} else bits.push("Ausweichen ohne 2 Energie");
	}
	const dealt = Math.min(d.body, end);
	d.body -= dealt;
	const bruch = gainBruch$1(state, d, Math.max(0, bruchMod));
	const line = `${aHero.name} trifft ${dHero.name}. ${diceNote} ${bits.join(", ")}. ${dealt} Körper, ${bruch} Bruch.`;
	note$1(state, line);
	if (d.body <= 0) {
		finish(state, attacker, "Körper");
		note$1(state, `${dHero.name} fällt. Körper auf 0.`);
	}
	return line;
}
function resolveBasis(input, choiceA, choiceB) {
	const state = structuredClone(input);
	const beats = [];
	if (state.over) return {
		state,
		beats
	};
	const choices = {
		A: clampChoice(state.fighters.A, choiceA),
		B: clampChoice(state.fighters.B, choiceB)
	};
	for (const side of ["A", "B"]) {
		const choice = choices[side];
		if (choice.action !== "block" || choice.energy <= 0) continue;
		const paid = Math.min(state.fighters[side].energy, choice.energy);
		state.fighters[side].energy -= paid;
		choices[side] = {
			action: "block",
			energy: paid
		};
	}
	const order = orderSides$1(state, choices);
	const first = order[0];
	const second = order[1];
	beats.push({
		kicker: `Runde ${state.round} · Aufdecken`,
		title: `${label$1(choices[first].action)} vor ${label$1(choices[second].action)}`,
		detail: `${nameOf(state, first)} handelt zuerst. Aktionswert ${basisActionValue(basisHero(state.fighters[first].heroId), choices[first])} gegen ${basisActionValue(basisHero(state.fighters[second].heroId), choices[second])}.`,
		tone: "idle"
	});
	for (const side of order) {
		const choice = choices[side];
		if (choice.action === "kampf") continue;
		const who = nameOf(state, side);
		if (choice.action === "block") {
			const line = `${who} blockt. Der erste Treffer dieser Runde ist um ${choice.energy >= 1 ? 4 : 3} niedriger, der Bruch daraus um 1.`;
			note$1(state, line);
			beats.push({
				kicker: `Runde ${state.round} · Block`,
				title: `${who} blockt`,
				detail: line,
				tone: "guard"
			});
		} else {
			const line = `${who} will ausweichen. Ein Treffer kostet 2 Energie und 2 Schaden, sonst verpufft es.`;
			note$1(state, line);
			beats.push({
				kicker: `Runde ${state.round} · Ausweichen`,
				title: `${who} weicht`,
				detail: line,
				tone: "guard"
			});
		}
	}
	for (const side of order) {
		if (state.over || choices[side].action !== "kampf") continue;
		const who = nameOf(state, side);
		const line = strike(state, side, choices);
		beats.push({
			kicker: `Runde ${state.round} · Kampf`,
			title: line.includes("verfehlt") ? `${who} verfehlt` : `${who} trifft`,
			detail: line,
			tone: state.over ? "win" : line.includes("verfehlt") ? "miss" : "hit"
		});
	}
	if (!state.over) {
		const losers = ["A", "B"].filter((side) => state.fighters[side].collapse && state.fighters[side].bruch >= state.fighters[side].bruchMax);
		if (losers.length === 1) {
			finish(state, other$1(losers[0]), "Bruch");
			note$1(state, `${nameOf(state, losers[0])} bricht zusammen.`);
		} else if (losers.length === 2) {
			finish(state, null, "Bruch");
			note$1(state, "Beide brechen zusammen.");
		} else if (state.round >= state.roundCap) {
			const a = state.fighters.A.body;
			const b = state.fighters.B.body;
			if (a === b) finish(state, null, "Zeit");
			else finish(state, a > b ? "A" : "B", "Zeit");
			note$1(state, "Die Zeit ist um. Es zählt der Körper.");
		} else note$1(state, "Die Runde endet.");
		beats.push({
			kicker: `Runde ${state.round} · Ende`,
			title: state.over ? winTitle$1(state) : "Die Runde endet",
			detail: state.log[state.log.length - 1] ?? "",
			tone: state.over ? "win" : "idle"
		});
	} else beats.push({
		kicker: `Runde ${state.round} · Entscheidung`,
		title: winTitle$1(state),
		detail: winDetail$1(state),
		tone: "win"
	});
	return {
		state,
		beats
	};
}
function winTitle$1(state) {
	if (!state.winner) return state.winReason === "Zeit" ? "Unentschieden" : "Beide brechen";
	return `${nameOf(state, state.winner)} siegt`;
}
function winDetail$1(state) {
	if (state.winReason === "Körper") return "Der Körper des Gegners ist auf 0.";
	if (state.winReason === "Bruch") return "Das Bruchmaximum hat die Runde beendet.";
	if (state.winReason === "Zeit") return "Nach 16 Runden zählt der verbleibende Körper.";
	return "Das Duell endet.";
}
function botBasisChoice(state) {
	const me = state.fighters.B;
	const mine = basisHero(me.heroId);
	const their = basisHero(state.fighters.A.heroId);
	const threatened = me.body <= Math.ceil(me.bodyMax * .35) || me.bruch >= me.bruchMax - 1;
	const hard = bonus$1(their.kraft) >= bonus$1(mine.schutz);
	if (threatened && hard) {
		if (bonus$1(mine.bewegung) >= 2 && me.energy >= 2 && state.round % 2 === 0) return {
			action: "ausweichen",
			energy: 0
		};
		return {
			action: "block",
			energy: me.energy >= 1 ? 1 : 0
		};
	}
	if (me.energy >= 3 && bonus$1(mine.kraft) >= 2) return {
		action: "kampf",
		energy: 3
	};
	if (me.energy >= 1) return {
		action: "kampf",
		energy: 1
	};
	return {
		action: "kampf",
		energy: 0
	};
}
function botBasisHero(playerId, seed) {
	const order = [
		"waechter",
		"brecher",
		"jaeger",
		"laeuferin",
		"archivar"
	];
	const start = Math.abs(seed) % order.length;
	for (let i = 0; i < order.length; i++) {
		const id = order[(start + i) % order.length];
		if (id !== playerId) return id;
	}
	return "waechter";
}
function basisSelfcheck() {
	const errors = [];
	const expect = (cond, message) => {
		if (!cond) errors.push(message);
	};
	expect(bonus$1(1) === 0 && bonus$1(4) === 1 && bonus$1(6) === 2 && bonus$1(8) === 3 && bonus$1(10) === 4, "Bonus-Tabelle");
	const brecher = basisPools(basisHero("brecher"));
	expect(brecher.body === 17 && brecher.energy === 4 && brecher.bruch === 6, "Brecher-Pools");
	const laeuferin = basisPools(basisHero("laeuferin"));
	expect(laeuferin.body === 15 && laeuferin.energy === 6 && laeuferin.bruch === 5, "Läuferin-Pools");
	const waechter = basisPools(basisHero("waechter"));
	expect(waechter.body === 20 && waechter.energy === 4 && waechter.bruch === 8, "Wächter-Pools");
	const bare = beginBasisRound(createBasis("brecher", "waechter", 7));
	const open = resolveBasis(bare, {
		action: "kampf",
		energy: 0
	}, {
		action: "kampf",
		energy: 0
	});
	const blocked = resolveBasis(structuredClone(bare), {
		action: "kampf",
		energy: 0
	}, {
		action: "block",
		energy: 0
	});
	expect(open.state.fighters.B.body <= bare.fighters.B.body, "Kampf senkt oder hält den Körper");
	expect(blocked.state.fighters.B.body >= open.state.fighters.B.body, "Block mildert denselben Schlag");
	expect(blocked.state.log.some((line) => line.includes("Block")), "Block steht im Protokoll");
	expect(!("echoes" in open.state.fighters.A), "Keine Echos");
	let state = beginBasisRound(createBasis("brecher", "archivar", 3));
	for (let i = 0; i < 16 && !state.over; i++) {
		const next = resolveBasis(state, {
			action: "kampf",
			energy: Math.min(3, state.fighters.A.energy)
		}, botBasisChoice(state));
		state = next.state.over ? next.state : beginBasisRound(next.state);
		expect(state.fighters.A.body >= 0 && state.fighters.B.body >= 0, "Körper nicht unter 0");
		expect(state.fighters.A.energy <= state.fighters.A.energyMax, "Energie im Maximum");
	}
	expect(state.over, "Ein Duell endet");
	if (state.winner) expect(state.winReason === "Körper" || state.winReason === "Bruch" || state.winReason === "Zeit", "Sieggrund");
	return errors;
}
function emptyChoice() {
	return {
		action: "kampf",
		energy: 0
	};
}
function initial$1() {
	return {
		screen: "title",
		mode: "bot",
		focus: "A",
		heroes: {
			A: "brecher",
			B: "waechter"
		},
		game: null,
		draft: emptyChoice(),
		locked: {},
		beats: [],
		frame: 0,
		pending: null,
		banner: ""
	};
}
function openFight(state, heroes) {
	const seed = 1 + Math.floor(Math.random() * 999983);
	const begun = beginBasisRound(createBasis(heroes.A, heroes.B, seed));
	return {
		...state,
		heroes,
		game: begun,
		banner: begun.log[begun.log.length - 1] ?? "",
		screen: state.mode === "hotseat" ? "cover" : "plan",
		focus: "A",
		draft: emptyChoice(),
		locked: {},
		beats: [],
		frame: 0,
		pending: null
	};
}
function reduce$1(state, act) {
	switch (act.type) {
		case "boot": return {
			...state,
			mode: act.mode,
			focus: "A",
			screen: "pick",
			draft: emptyChoice()
		};
		case "hero": return {
			...state,
			heroes: {
				...state.heroes,
				[state.focus]: act.id
			}
		};
		case "advance": {
			if (state.screen !== "pick") return state;
			if (state.mode === "hotseat" && state.focus === "A") return {
				...state,
				screen: "cover",
				focus: "B"
			};
			const heroes = { ...state.heroes };
			if (state.mode === "bot") heroes.B = botBasisHero(heroes.A, heroes.A.length + 3);
			return openFight(state, heroes);
		}
		case "back":
			if (state.screen === "pick" && state.focus === "B") return {
				...state,
				screen: "pick",
				focus: "A"
			};
			if (state.screen === "pick") return {
				...state,
				screen: "title",
				focus: "A"
			};
			return state;
		case "ready": return {
			...state,
			screen: state.focus === "B" && !state.game ? "pick" : "plan",
			draft: emptyChoice()
		};
		case "draft": return {
			...state,
			draft: act.choice
		};
		case "lock": {
			if (!state.game || state.game.over) return state;
			const mine = clampDraft(state.game.fighters[state.focus], state.draft);
			if (state.mode === "bot") {
				const bot = botBasisChoice(state.game);
				const resolved = resolveBasis(state.game, mine, bot);
				return {
					...state,
					locked: {
						A: mine,
						B: bot
					},
					pending: resolved.state,
					beats: resolved.beats,
					frame: 0,
					screen: "scene"
				};
			}
			const locked = {
				...state.locked,
				[state.focus]: mine
			};
			if (state.focus === "A") return {
				...state,
				locked,
				screen: "cover",
				focus: "B",
				draft: emptyChoice()
			};
			const resolved = resolveBasis(state.game, locked.A ?? mine, mine);
			return {
				...state,
				locked,
				pending: resolved.state,
				beats: resolved.beats,
				frame: 0,
				screen: "scene"
			};
		}
		case "step": {
			if (state.frame < state.beats.length - 1) return {
				...state,
				frame: state.frame + 1
			};
			const next = state.pending;
			if (!next) return state;
			if (next.over) return {
				...state,
				game: next,
				pending: null,
				screen: "end",
				beats: [],
				frame: 0
			};
			const begun = beginBasisRound(next);
			return {
				...state,
				game: begun,
				pending: null,
				banner: begun.log[begun.log.length - 1] ?? "",
				screen: state.mode === "hotseat" ? "cover" : "plan",
				focus: "A",
				draft: emptyChoice(),
				locked: {},
				beats: [],
				frame: 0
			};
		}
		case "rematch": return openFight(state, state.heroes);
		case "title": return {
			...initial$1(),
			mode: state.mode
		};
		default: return state;
	}
}
function clampDraft(f, choice) {
	if (choice.action === "ausweichen") return {
		action: "ausweichen",
		energy: 0
	};
	const cap = choice.action === "block" ? 1 : 3;
	return {
		action: choice.action,
		energy: Math.max(0, Math.min(cap, choice.energy, f.energy))
	};
}
function downloadText$1(filename, text) {
	const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function BasisApp({ onFull }) {
	const [duel, dispatch] = (0, import_react.useReducer)(reduce$1, void 0, initial$1);
	const [codex, setCodex] = (0, import_react.useState)(false);
	const [checked, setChecked] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const errors = basisSelfcheck();
		setChecked(errors.length ? errors.join(" · ") : "");
	}, []);
	(0, import_react.useEffect)(() => {
		if (duel.screen !== "scene") return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const timer = window.setTimeout(() => dispatch({ type: "step" }), 1600);
		return () => window.clearTimeout(timer);
	}, [
		duel.screen,
		duel.frame,
		duel.beats.length
	]);
	const beat = duel.screen === "scene" ? duel.beats[duel.frame] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			duel.screen === "title" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title$1, {
				onFull,
				onBoot: (mode) => dispatch({
					type: "boot",
					mode
				})
			}),
			duel.screen === "pick" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pick, {
				duel,
				dispatch
			}),
			duel.screen === "cover" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover$1, {
				duel,
				dispatch
			}),
			(duel.screen === "plan" || duel.screen === "scene") && duel.game && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fight, {
				duel,
				beat,
				dispatch,
				onCodex: () => setCodex(true)
			}),
			duel.screen === "end" && duel.game && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ending$1, {
				duel,
				dispatch
			}),
			codex && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Codex$1, { onClose: () => setCodex(false) }),
			checked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "fixed bottom-3 left-3 right-3 rounded-md bg-accent px-3 py-2 text-sm text-fg",
				role: "alert",
				children: ["Basisprüfung: ", checked]
			})
		]
	});
}
function Title$1({ onFull, onBoot }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-3xl flex-col justify-center gap-8 px-4 py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "max-w-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Basis · zum Prüfen"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-2 text-5xl sm:text-6xl",
					children: "ECHO//BRUCH"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-md text-muted",
					children: "Zwei Spielkarten, nur die fünf Grundwerte. Keine Waffe, keine Ausrüstung, keine Echos. Eine Runde ist Kampf, Block oder Ausweichen."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-primary",
					onClick: () => onBoot("bot"),
					children: "Gegen den Bot"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: () => onBoot("hotseat"),
					children: "Zu zweit am Gerät"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: onFull,
					children: "Volles Duell"
				})
			]
		})]
	});
}
function Pick({ duel, dispatch }) {
	const current = duel.heroes[duel.focus];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-6xl flex-col gap-6 px-4 py-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: duel.focus === "A" ? "Spieler A" : "Spieler B"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display text-4xl",
				children: "Spielkarte"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: () => dispatch({ type: "back" }),
					children: "Zurück"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-primary",
					onClick: () => dispatch({ type: "advance" }),
					children: "Diese Karte"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-5",
			children: BASIS_HEROES.map((hero) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spielkarte, {
				heroId: hero.id,
				selected: hero.id === current,
				onPick: () => dispatch({
					type: "hero",
					id: hero.id
				})
			}, hero.id))
		})]
	});
}
function Cover$1({ duel, dispatch }) {
	const who = duel.focus === "A" ? "Spieler A" : "Spieler B";
	const picking = !duel.game;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-6 px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: picking ? "Nächste Karte" : "Verdecktes Planen"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display text-5xl",
				children: who
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-muted",
				children: "Gib das Gerät weiter. Die andere Wahl bleibt zu."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => dispatch({ type: "ready" }),
				children: "Ich bin bereit"
			})
		]
	});
}
function Fight({ duel, beat, dispatch, onCodex }) {
	const game = duel.screen === "scene" && duel.pending ? duel.pending : duel.game;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-5xl flex-col gap-4 px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "display text-xl",
					children: "ECHO//BRUCH"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: beat ? beat.kicker : `Runde ${game.round} · Planen`
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: onCodex,
						children: "Regeln"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => dispatch({ type: "title" }),
						children: "Menü"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveCard, {
					fighter: game.fighters.A,
					tag: "Spieler A"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveCard, {
					fighter: game.fighters.B,
					tag: duel.mode === "bot" ? "Bot" : "Spieler B"
				})]
			}),
			duel.screen === "plan" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Planner$1, {
				duel,
				dispatch
			}),
			beat && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: beat.kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display mt-1 text-3xl",
						children: beat.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: beat.detail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-primary",
							onClick: () => dispatch({ type: "step" }),
							children: "Weiter"
						})
					})
				]
			})
		]
	});
}
function Planner$1({ duel, dispatch }) {
	const mine = duel.game.fighters[duel.focus];
	const hero = basisHero(mine.heroId);
	const draft = clampDraft(mine, duel.draft);
	const value = basisActionValue(hero, draft);
	const actions = [
		{
			id: "kampf",
			name: "Kampf",
			text: "Unbewaffneter Schlag. Kraftbonus, plus eingesetzte Energie.",
			icon: Swords
		},
		{
			id: "block",
			name: "Block",
			text: "Der erste Treffer ist um 3 niedriger, mit 1 Energie um 4.",
			icon: Shield
		},
		{
			id: "ausweichen",
			name: "Ausweichen",
			text: "Kein Schlag. Ein Treffer kostet 2 Energie und nimmt 2 Schaden.",
			icon: Footprints
		}
	];
	const energyCap = draft.action === "kampf" ? 3 : draft.action === "block" ? 1 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel flex flex-col gap-3 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-baseline justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						duel.focus === "A" ? "Spieler A" : "Spieler B",
						" · ",
						hero.name
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm tabular-nums text-muted",
					children: ["Aktionswert ", value]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: duel.banner
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-3",
				children: actions.map((action) => {
					const Icon = action.icon;
					const on = draft.action === action.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: `panel p-3 text-left ${on ? "border-fg" : ""}`,
						onClick: () => dispatch({
							type: "draft",
							choice: {
								action: action.id,
								energy: action.id === "ausweichen" ? 0 : draft.energy
							}
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2 font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 16 }), action.name]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm text-muted",
							children: action.text
						})]
					}, action.id);
				})
			}),
			energyCap > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: "Energie"
					}),
					Array.from({ length: energyCap + 1 }, (_, energy) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `btn ${draft.energy === energy ? "btn-primary" : ""}`,
						disabled: energy > mine.energy,
						onClick: () => dispatch({
							type: "draft",
							choice: {
								action: draft.action,
								energy
							}
						}),
						children: energy
					}, energy)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-faint",
						children: energyHint(draft)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-primary",
					onClick: () => dispatch({ type: "lock" }),
					children: "Verdeckt festlegen"
				})
			})
		]
	});
}
function energyHint(choice) {
	if (choice.action === "block") return choice.energy >= 1 ? "Block mildert um 4." : "Block mildert um 3.";
	if (choice.energy >= 3) return "+2 Rohschaden, +1 Bruch.";
	if (choice.energy >= 2) return "+1 Rohschaden, +1 Bruch.";
	if (choice.energy >= 1) return "+1 Rohschaden.";
	return "Keine zusätzliche Wucht.";
}
function Ending$1({ duel, dispatch }) {
	const game = duel.game;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-xl flex-col justify-center gap-6 px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Runde ",
					game.round,
					" · Basis"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display text-5xl",
				children: winTitle$1(game)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: winDetail$1(game)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex max-h-80 flex-col gap-2 overflow-auto text-sm text-muted",
				children: [...game.log].reverse().map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, `${index}-${line}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: () => dispatch({ type: "rematch" }),
						children: "Nochmal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => downloadText$1(`echo-bruch-basis-${game.seed}.txt`, [...game.log].reverse().join("\n")),
						children: "Protokoll speichern"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => dispatch({ type: "title" }),
						children: "Andere Karten"
					})
				]
			})
		]
	});
}
function Spielkarte({ heroId, selected, onPick }) {
	const hero = basisHero(heroId);
	const pools = basisPools(hero);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onPick,
		className: `panel flex flex-col gap-3 p-4 text-left ${selected ? "border-fg" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sigil$1, { id: hero.id }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "display block text-2xl",
				children: hero.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-muted",
				children: hero.line
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Kraft",
				value: hero.kraft
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Schutz",
				value: hero.schutz
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Bewegung",
				value: hero.bewegung
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Kontrolle",
				value: hero.kontrolle,
				hint: "ruht"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Tempo",
				value: hero.tempo
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm tabular-nums text-muted",
				children: [
					"Körper ",
					pools.body,
					" · Energie ",
					pools.energy,
					" · Bruch ",
					pools.bruch
				]
			})
		]
	});
}
function LiveCard({ fighter, tag }) {
	const hero = basisHero(fighter.heroId);
	const open = fighter.bruch >= Math.ceil(fighter.bruchMax / 2);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel flex flex-col gap-3 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sigil$1, { id: hero.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display text-2xl",
						children: hero.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: hero.line
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: tag
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-5 gap-2 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Kraft",
						value: hero.kraft
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Schutz",
						value: hero.schutz
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Bewegung",
						value: hero.bewegung
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Kontrolle",
						value: hero.kontrolle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Tempo",
						value: hero.tempo
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter$1, {
				label: "Körper",
				value: fighter.body,
				max: fighter.bodyMax,
				tone: "body"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter$1, {
				label: "Bruch",
				value: fighter.bruch,
				max: fighter.bruchMax,
				tone: "bruch"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted",
					children: "Energie"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex gap-1",
					children: Array.from({ length: fighter.energyMax }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `pip ${i < fighter.energy ? "on-guard" : ""}` }, i))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "min-h-5 text-xs text-muted",
				children: fighter.collapse ? "Letzte Runde" : open ? "Offen" : "Stabil"
			})
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center justify-between gap-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-muted",
			children: [label, hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-faint",
				children: [" · ", hint]
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children: value
		})]
	});
}
function Mini({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "block text-[10px] uppercase tracking-wide text-faint",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "tabular-nums",
		children: value
	})] });
}
function Meter$1({ label, value, max, tone }) {
	const pct = max <= 0 ? 0 : Math.max(0, Math.min(100, value / max * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex justify-between text-xs text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "tabular-nums",
			children: [
				value,
				"/",
				max
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 rounded-full bg-raised",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `h-full rounded-full ${tone === "bruch" ? "bg-accent" : "bg-fg"}`,
			style: { width: `${pct}%` }
		})
	})] });
}
function Sigil$1({ id }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 48 48",
		className: "h-10 w-10 shrink-0 text-soft",
		"aria-hidden": "true",
		children: [
			id === "brecher" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 36 L24 8 L40 36 Z",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			id === "laeuferin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 32 C16 8 32 8 40 32",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			id === "archivar" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "10",
				y: "10",
				width: "28",
				height: "28",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			id === "waechter" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 16 H40 V28 C40 36 32 40 24 40 C16 40 8 36 8 28 Z",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			id === "jaeger" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "24",
				cy: "24",
				r: "12",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			})
		]
	});
}
function Codex$1({ onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-20 flex items-end justify-center bg-bg/80 p-3 sm:items-center",
		role: "dialog",
		"aria-label": "Basisregeln",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel max-h-[80dvh] w-full max-w-lg overflow-auto p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display text-3xl",
					children: "Basis"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: onClose,
					children: "Schließen"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-3 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Es gelten die Kartenwerte aus dem Regelwerk, nicht der spätere Ausgleich. Fähigkeiten, Waffen, Rüstung, Werkzeug, Artefakte, Items und Echos sind zurückgestellt." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Körper ist 12 plus Schutz. Energie ist 4 plus Bewegung geteilt durch 3, mindestens 3 und höchstens 8. Bruch ist 4 plus Schutz geteilt durch 2. Beginn mit 2 Energie, jede Runde plus 2." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kampf trifft, wenn Würfel plus Kraftbonus plus Energie mindestens 2 plus Schutzbonus plus Bewegungsbonus erreicht. Ohne Waffe ist der Rohschaden nur der Kraftbonus, plus 1 bei 1 oder 2 Energie und plus 2 bei 3. Ab 2 Energie gibt es 1 Bruch. Eine 6 verdoppelt den Endschaden." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Block senkt den ersten Treffer um 3, mit 1 Energie um 4, und nimmt dem Treffer 1 Bruch. Ausweichen ist kein Schlag: liegt der Treffer, kostet er 2 Energie und 2 Schaden. Ohne Feld gibt es kein Entkommen aus der Reichweite." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Höherer Aktionswert handelt zuerst: Tempo, minus 1 bei Block, plus 2 bei Ausweichen, plus eingesetzte Energie. Körper auf 0 endet sofort. Bruchmaximum endet nach dieser Runde. Nach 16 Runden zählt der Körper." })
				]
			})]
		})
	});
}
var CHARACTERS = [
	{
		id: "brecher",
		name: "Brecher",
		line: "Schwerer Treffer",
		kraft: 8,
		schutz: 5,
		bewegung: 2,
		kontrolle: 2,
		tempo: 3,
		cores: [
			"attack",
			"attack",
			"guard"
		],
		passive: "Ab 5 Endschaden erhält das Ziel 1 zusätzlichen Bruch.",
		ability: "Aufbrechen",
		abilityCost: 3,
		abilityAction: "attack",
		abilityText: "Angriff, Reichweite 1. Treffer: +2 Rohschaden, Schutz endet, ein Schutz-Echo verliert 1 Ladung."
	},
	{
		id: "laeuferin",
		name: "Läuferin",
		line: "Durchgang",
		kraft: 5,
		schutz: 5,
		bewegung: 8,
		kontrolle: 5,
		tempo: 8,
		cores: [
			"move",
			"move",
			"influence"
		],
		passive: "Ignoriert den ersten negativen Feldmarker, den sie in der Runde betritt. Hat sie sich einmal bewegt, tragen ihre Angriffe in diesem Kampf +2 Rohschaden und ignorieren 2 Schutzbonus und 2 Rüstung.",
		ability: "Seitenwechsel",
		abilityCost: 2,
		abilityAction: "move",
		abilityText: "Bis zu 2 Felder bewegen. Danach ein Bewegungs-Echo mit 1 Ladung. Der Weg öffnet den nächsten Angriff."
	},
	{
		id: "archivar",
		name: "Archivar",
		line: "Speichern",
		kraft: 3,
		schutz: 6,
		bewegung: 4,
		kontrolle: 9,
		tempo: 4,
		cores: [
			"influence",
			"guard",
			"move"
		],
		passive: "Ein durch Einfluss ohne Item erzeugtes Echo erhält 1 zusätzliche Ladung. Ein eigenes Echo auf dem Feld gibt +2 Verteidigung. Der erste Treffer des Kampfes ist um 6 Körper niedriger und legt ein Schutz-Echo mit 2 Ladungen.",
		ability: "Verbindung",
		abilityCost: 3,
		abilityAction: "influence",
		abilityText: "Zwei eigene Echos verstärken sich um 1 Ladung und gelten diese Runde als benutzt. Fehlen sie, entsteht zuerst ein Schutz-Echo mit 2 Ladungen."
	},
	{
		id: "waechter",
		name: "Wächter",
		line: "Standhalten",
		kraft: 4,
		schutz: 8,
		bewegung: 2,
		kontrolle: 5,
		tempo: 2,
		cores: [
			"guard",
			"guard",
			"influence"
		],
		passive: "Gegnerische Fähigkeiten verschieben höchstens um 2 Felder.",
		ability: "Sperre",
		abilityCost: 2,
		abilityAction: "guard",
		abilityText: "Schutzmarker auf dem eigenen Feld und bis zum Rundenende +1 Schutzbonus."
	},
	{
		id: "jaeger",
		name: "Jäger",
		line: "Verfolgen",
		kraft: 7,
		schutz: 4,
		bewegung: 5,
		kontrolle: 4,
		tempo: 7,
		cores: [
			"attack",
			"move",
			"influence"
		],
		passive: "Verlässt der Gegner sein Feld, +1 Angriffswert gegen ihn bis zum Rundenende. Der erste Treffer des Kampfes ist um 4 Körper niedriger.",
		ability: "Markieren",
		abilityCost: 1,
		abilityAction: "influence",
		abilityText: "Ziel in Reichweite 3 markieren. Der nächste Angriff: +2 Angriffswert, ignoriert 2 Schutzbonus und 1 Rüstung, Angriffs-Echo mit 2 Ladungen."
	}
];
var WEAPONS = [
	{
		id: "kurzschwert",
		name: "Kurzschwert",
		value: 3,
		range: 1,
		tempo: 2,
		text: "Nach Treffer 1 Feld zurück. Keine Angriffe durch Barrieren."
	},
	{
		id: "hammer",
		name: "Schwerer Hammer",
		value: 6,
		range: 1,
		tempo: -2,
		text: "Treffer: +1 Bruch. Verfehlt: Träger +1 Bruch."
	},
	{
		id: "speer",
		name: "Speer",
		value: 4,
		range: 2,
		tempo: 0,
		text: "Darf durch einen Kämpfer hindurch treffen. Auf demselben Feld −1 Rohschaden."
	},
	{
		id: "bogen",
		name: "Bogen",
		value: 4,
		range: 3,
		tempo: 1,
		text: "Ignoriert den ersten Bewegungsbonus des Ziels. Nicht bei Gebunden."
	},
	{
		id: "kette",
		name: "Kettenklinge",
		value: 3,
		range: 2,
		tempo: 1,
		text: "Bei Treffer das Ziel 1 Feld näher ziehen, kostet 1 Energie."
	}
];
var ARMORS = [
	{
		id: "leder",
		name: "Leder",
		value: 1,
		body: 1,
		tempo: 1,
		kontrolle: 0,
		text: "Die erste Bewegung der Runde kostet 1 Energie weniger."
	},
	{
		id: "ketten",
		name: "Kettenrüstung",
		value: 2,
		body: 3,
		tempo: -1,
		kontrolle: 0,
		text: "Der erste Bruch der Runde ist um 1 niedriger."
	},
	{
		id: "platte",
		name: "Plattenrüstung",
		value: 3,
		body: 5,
		tempo: -2,
		kontrolle: 0,
		text: "Höchstens 1 Feld verschoben. Bewegungsweite −1."
	},
	{
		id: "spiegel",
		name: "Spiegelfaser",
		value: 1,
		body: 1,
		tempo: 0,
		kontrolle: 1,
		text: "Einmal pro Runde +1 Verteidigung gegen einen Echo-Angriff."
	}
];
var GEAR = [
	{
		id: "greifhaken",
		name: "Greifhaken",
		slot: "tool",
		text: "Bewegungsbonus +1, Tempo +1, +1 Feld Weite."
	},
	{
		id: "rauch",
		name: "Rauchkapsel",
		slot: "tool",
		text: "Kontrollbonus +1. Nebel auf dem eigenen Feld, 2 Energie."
	},
	{
		id: "brecheisen",
		name: "Brecheisen",
		slot: "tool",
		text: "Kraftbonus +1. Einfluss gegen Barrieren und Schutzmarker trifft doppelt."
	},
	{
		id: "anker",
		name: "Ankerring",
		slot: "tool",
		text: "Schutzbonus +1, Bewegungsbonus −1. Nicht durch gegnerische Züge verschiebbar."
	},
	{
		id: "spiegelkern",
		name: "Spiegelkern",
		slot: "artifact",
		text: "Kontrolle +2, maximale Energie −1. Einmal ohne Energie umwandeln."
	},
	{
		id: "zeitnadel",
		name: "Zeitnadel",
		slot: "artifact",
		text: "Tempo +2, Körper −2. Einmal pro Kampf +2 Aktionswert."
	},
	{
		id: "bruchstein",
		name: "Bruchstein",
		slot: "artifact",
		text: "Bruchmaximum +2, Kontrolle −1. Einmal pro Runde 1 Bruch gegen 2 Energie."
	},
	{
		id: "maske",
		name: "Leere Maske",
		slot: "artifact",
		text: "Bewegungsbonus +1, Kontrolle +1. Einmal das Ziel um ein Feld verschieben."
	}
];
var ITEMS = [
	{
		id: "heil",
		name: "Heilmittel",
		text: "4 Körper. Entfernt Verletzt."
	},
	{
		id: "zelle",
		name: "Energiezelle",
		text: "3 Energie, nicht über das Maximum."
	},
	{
		id: "binde",
		name: "Bruchbinde",
		text: "2 Bruch weniger. Gebunden bis Ende der nächsten Runde."
	},
	{
		id: "splitter",
		name: "Echo-Splitter",
		text: "Ein eigenes Echo erhält 2 Ladungen, höchstens 3."
	},
	{
		id: "blend",
		name: "Blendpulver",
		text: "Ziel wird Verwirrt. Ist es das schon, 1 Bruch."
	}
];
var ACTIONS = [
	{
		id: "attack",
		name: "Angriff",
		tempo: 0,
		text: "Treffer nach Würfel, Kraft und Waffe."
	},
	{
		id: "guard",
		name: "Schutz",
		tempo: -1,
		text: "Der nächste Treffer wird schwächer."
	},
	{
		id: "move",
		name: "Bewegung",
		tempo: 2,
		text: "Felder entlang der Verbindungen."
	},
	{
		id: "influence",
		name: "Einfluss",
		tempo: 0,
		text: "Echos, Kerne und Spuren."
	}
];
var REACTIONS = [
	{
		id: "dodge",
		name: "Ausweichen",
		cost: 2,
		text: "Nach Treffer, wenn du Bewegung gewählt hast: 1 Feld, 2 Schaden weniger."
	},
	{
		id: "riposte",
		name: "Gegenstoß",
		cost: 2,
		text: "Nach Treffer, wenn du Angriff gewählt hast: Gegenangriff, −2 Rohschaden, kein Krit."
	},
	{
		id: "stabilize",
		name: "Stabilisieren",
		cost: 1,
		text: "Wenn du mindestens 2 Bruch erhieltest: 1 verhindern. Nächste Runde −1 Energie."
	},
	{
		id: "secure",
		name: "Echo sichern",
		cost: 2,
		text: "Ein Echo, das zerstört würde, bleibt mit 1 Ladung. Du erhältst 1 Bruch."
	}
];
var EDGES = [
	[1, 2],
	[1, 3],
	[2, 3],
	[2, 4],
	[2, 5],
	[3, 4],
	[3, 5],
	[4, 5],
	[4, 6],
	[4, 7],
	[5, 6],
	[5, 7],
	[6, 7]
];
var POS = {
	1: [500, 160],
	2: [290, 400],
	3: [710, 400],
	4: [230, 700],
	5: [770, 700],
	6: [320, 1010],
	7: [680, 1010]
};
var STARTS = {
	A: [2, 4],
	B: [3, 5]
};
var ECHO_LABEL = {
	attack: "Angriff",
	guard: "Schutz",
	move: "Bewegung",
	influence: "Einfluss",
	trap: "Falle",
	barrier: "Barriere",
	mist: "Nebel",
	rift: "Riss"
};
function byId(list, id) {
	const found = list.find((x) => x.id === id);
	if (!found) throw new Error(`Unbekannt: ${id}`);
	return found;
}
var SUGGESTED = {
	brecher: {
		weaponId: "hammer",
		armorId: "platte",
		toolId: "brecheisen",
		artifactId: "anker",
		items: ["heil", "binde"]
	},
	laeuferin: {
		weaponId: "kurzschwert",
		armorId: "leder",
		toolId: "greifhaken",
		artifactId: "maske",
		items: ["zelle", "blend"]
	},
	archivar: {
		weaponId: "kette",
		armorId: "spiegel",
		toolId: "rauch",
		artifactId: "spiegelkern",
		items: ["splitter", "zelle"]
	},
	waechter: {
		weaponId: "speer",
		armorId: "ketten",
		toolId: "anker",
		artifactId: "bruchstein",
		items: ["heil", "binde"]
	},
	jaeger: {
		weaponId: "bogen",
		armorId: "leder",
		toolId: "greifhaken",
		artifactId: "zeitnadel",
		items: ["blend", "splitter"]
	}
};
var NEIGHBORS = {};
for (let i = 1; i <= 7; i++) NEIGHBORS[i] = [];
for (const [a, b] of EDGES) {
	NEIGHBORS[a].push(b);
	NEIGHBORS[b].push(a);
}
function neighbors(id) {
	return NEIGHBORS[id];
}
function other(side) {
	return side === "A" ? "B" : "A";
}
function clone(value) {
	return JSON.parse(JSON.stringify(value));
}
function bonus(value) {
	if (value <= 2) return 0;
	if (value <= 4) return 1;
	if (value <= 6) return 2;
	if (value <= 8) return 3;
	return 4;
}
function roll(state) {
	state.seed = state.seed + 1831565813 | 0;
	let t = Math.imul(state.seed ^ state.seed >>> 15, 1 | state.seed);
	t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
	return ((t ^ t >>> 14) >>> 0) / 4294967296;
}
function d6(state) {
	return 1 + Math.floor(roll(state) * 6);
}
function uid(state, prefix) {
	state.nextId += 1;
	return `${prefix}${state.nextId}`;
}
function characterOf(id) {
	return byId(CHARACTERS, id);
}
function hasStatus(f, kind) {
	return f.statuses.some((s) => s.kind === kind);
}
function isOpen(f) {
	return f.bruch >= Math.ceil(f.bruchMax / 2) || hasStatus(f, "open");
}
function liveStats(f) {
	const c = characterOf(f.characterId);
	const weapon = byId(WEAPONS, f.weaponId);
	const armor = byId(ARMORS, f.armorId);
	let kraft = c.kraft;
	let schutz = c.schutz;
	let bewegung = c.bewegung;
	let kontrolle = c.kontrolle + armor.kontrolle;
	let tempo = c.tempo + weapon.tempo + armor.tempo;
	let kraftB = bonus(kraft);
	let schutzB = bonus(schutz) + f.guardBonus;
	let moveB = bonus(bewegung);
	let konB = bonus(kontrolle);
	let moveRange = 1 + Math.floor(bewegung / 3);
	if (f.armorId === "platte") moveRange -= 1;
	if (f.toolId === "greifhaken" || f.artifactId === "greifhaken") {
		moveB += 1;
		tempo += 1;
		moveRange += 1;
	}
	if (f.toolId === "rauch" || f.artifactId === "rauch") konB += 1;
	if (f.toolId === "brecheisen" || f.artifactId === "brecheisen") kraftB += 1;
	if (f.toolId === "anker" || f.artifactId === "anker") {
		schutzB += 1;
		moveB -= 1;
	}
	if (f.toolId === "spiegelkern" || f.artifactId === "spiegelkern") konB += 2;
	if (f.toolId === "zeitnadel" || f.artifactId === "zeitnadel") tempo += 2;
	if (f.toolId === "bruchstein" || f.artifactId === "bruchstein") konB -= 1;
	if (f.toolId === "maske" || f.artifactId === "maske") {
		moveB += 1;
		konB += 1;
	}
	if (f.toolId === "greifhaken") {}
	moveB = Math.max(0, moveB);
	konB = Math.max(0, konB);
	return {
		kraft,
		schutz,
		bewegung,
		kontrolle,
		tempo,
		kraftB,
		schutzB,
		moveB,
		konB,
		weapon: weapon.value,
		range: weapon.range,
		armor: armor.value,
		moveRange: Math.max(1, moveRange)
	};
}
function derivedMax(setup) {
	const c = characterOf(setup.characterId);
	const armor = byId(ARMORS, setup.armorId);
	const gear = [setup.toolId, setup.artifactId];
	let body = 12 + c.schutz + armor.body;
	let energy = 4 + Math.floor(c.bewegung / 3);
	let bruch = 4 + Math.floor(c.schutz / 2);
	if (gear.includes("spiegelkern")) energy -= 1;
	if (gear.includes("zeitnadel")) body -= 2;
	if (gear.includes("bruchstein")) bruch += 2;
	energy = Math.max(3, Math.min(8, energy));
	return {
		body,
		energy,
		bruch
	};
}
function suggestedSetup(characterId, side) {
	const kit = SUGGESTED[characterId];
	return {
		characterId,
		weaponId: kit.weaponId,
		armorId: kit.armorId,
		toolId: kit.toolId,
		artifactId: kit.artifactId,
		items: [...kit.items],
		field: side === "A" ? 2 : 5
	};
}
function createFighter(setup, side) {
	const max = derivedMax(setup);
	const c = characterOf(setup.characterId);
	const gear = [setup.toolId, setup.artifactId];
	return {
		side,
		characterId: setup.characterId,
		weaponId: setup.weaponId,
		armorId: setup.armorId,
		toolId: setup.toolId,
		artifactId: setup.artifactId,
		items: setup.items.map((id) => ({
			id,
			spent: false
		})),
		field: setup.field,
		body: max.body,
		bodyMax: max.body,
		energy: 2,
		energyMax: max.energy,
		bruch: 0,
		bruchMax: max.bruch,
		statuses: [],
		echoes: [],
		cores: c.cores.map((kind) => ({
			kind,
			points: 3,
			revealed: false
		})),
		lastAction: null,
		pattern: {
			attack: 0,
			guard: 0,
			move: 0,
			influence: 0
		},
		ruleBreak: true,
		collapse: false,
		stabilizeNext: false,
		marked: false,
		pursued: false,
		guardBonus: 0,
		abilityRound: 0,
		stoneRound: 0,
		maskReady: gear.includes("maske"),
		nadelReady: gear.includes("zeitnadel"),
		convertReady: gear.includes("spiegelkern"),
		braceLeft: 0,
		predictStrike: false,
		ketteUsed: false,
		spiegelUsed: false,
		leatherUsed: false,
		ignoreUsed: false,
		moved: false,
		flank: false,
		sheltered: false
	};
}
function createGame(a, b, seed = Date.now() % 1e6) {
	return {
		round: 0,
		startSide: "A",
		fighters: {
			A: createFighter(a, "A"),
			B: createFighter(b, "B")
		},
		markers: [],
		log: [],
		winner: null,
		winReason: null,
		over: false,
		seed,
		nextId: 1,
		updatedRound: 0
	};
}
function emptyPlan() {
	return {
		action: "guard",
		energy: 0,
		targetField: null,
		reaction: null,
		itemId: null,
		ability: false,
		influence: "spur",
		echoId: null,
		ruleBreak: null,
		retargetField: null,
		prediction: null,
		zeitnadel: false,
		mist: false,
		mask: false,
		freeConvert: false
	};
}
function distance(from, to) {
	if (from === to) return 0;
	const seen = /* @__PURE__ */ new Set([from]);
	let edge = [from];
	let steps = 0;
	while (edge.length) {
		steps += 1;
		const next = [];
		for (const id of edge) for (const n of neighbors(id)) {
			if (seen.has(n)) continue;
			if (n === to) return steps;
			seen.add(n);
			next.push(n);
		}
		edge = next;
	}
	return 99;
}
function shortestPath(from, to, blocked) {
	if (from === to) return [from];
	const prev = /* @__PURE__ */ new Map();
	const seen = /* @__PURE__ */ new Set([from]);
	let edge = [from];
	while (edge.length) {
		const next = [];
		for (const id of edge) for (const n of neighbors(id)) {
			if (seen.has(n)) continue;
			if (blocked != null && n === blocked && n !== to) continue;
			seen.add(n);
			prev.set(n, id);
			if (n === to) {
				const path = [to];
				let cur = to;
				while (cur !== from) {
					cur = prev.get(cur);
					path.push(cur);
				}
				return path.reverse();
			}
			next.push(n);
		}
		edge = next;
	}
	return null;
}
function reachable(from, steps, blocked) {
	const found = /* @__PURE__ */ new Set();
	let edge = [from];
	const seen = /* @__PURE__ */ new Set([from]);
	for (let i = 0; i < steps; i++) {
		const next = [];
		for (const id of edge) for (const n of neighbors(id)) {
			if (seen.has(n) || n === blocked) continue;
			seen.add(n);
			found.add(n);
			next.push(n);
		}
		edge = next;
	}
	return [...found].sort((a, b) => a - b);
}
function pathInteriors(from, to) {
	const path = shortestPath(from, to, null);
	if (!path || path.length < 3) return [];
	return path.slice(1, -1);
}
function note(state, line) {
	state.log.unshift(line);
}
function addStatus(f, kind, rounds, power = 0) {
	const existing = f.statuses.find((s) => s.kind === kind);
	if (existing) {
		existing.rounds = Math.max(existing.rounds, rounds);
		existing.power = Math.max(existing.power, power);
		return;
	}
	f.statuses.push({
		kind,
		rounds,
		power
	});
}
function removeStatus(f, kind) {
	f.statuses = f.statuses.filter((s) => s.kind !== kind);
}
function markerAt(state, field) {
	return state.markers.find((m) => m.field === field);
}
function placeMarker(state, owner, kind, field, duration) {
	state.markers = state.markers.filter((m) => m.field !== field);
	state.markers.push({
		id: uid(state, "m"),
		owner,
		kind,
		field,
		duration
	});
}
function pushEcho(state, echo) {
	const owner = state.fighters[echo.owner];
	if (owner.echoes.length >= 4) {
		owner.echoes.sort((a, b) => a.charges - b.charges);
		owner.echoes.shift();
	}
	owner.echoes.push({
		id: uid(state, "e"),
		used: true,
		ttl: echo.ttl ?? 0,
		...echo
	});
}
function influenceRange(state, f) {
	return f.echoes.find((e) => e.kind === "influence" && e.field === f.field && e.charges > 0) ? 4 : 3;
}
function moveSteps(f, energy, ability) {
	if (ability && f.characterId === "laeuferin") return 2;
	let steps = liveStats(f).moveRange;
	if (energy >= 1) steps += 1;
	if (energy >= 2) steps += 1;
	if (hasStatus(f, "bound")) steps -= 1;
	return Math.max(0, steps);
}
function actionTempo(action) {
	if (action === "guard") return -1;
	if (action === "move") return 2;
	return 0;
}
function actionValue(f, plan) {
	let value = liveStats(f).tempo + actionTempo(plan.action) + plan.energy;
	if (plan.zeitnadel) value += 2;
	if (f.predictStrike && plan.action) value += 2;
	return value;
}
function botSetup(player, difficulty) {
	if (difficulty === "brutal") return suggestedSetup("brecher", "B");
	if (difficulty === "bedacht") return suggestedSetup("waechter", "B");
	const c = characterOf(player.characterId);
	if (c.bewegung >= 7) return suggestedSetup("jaeger", "B");
	if (c.kraft >= 7) return suggestedSetup("waechter", "B");
	if (c.kontrolle >= 8) return suggestedSetup("laeuferin", "B");
	return suggestedSetup("archivar", "B");
}
var CONVERT = {
	attack: "trap",
	guard: "barrier",
	move: "mist",
	influence: "rift"
};
function name(f) {
	return {
		brecher: "Brecher",
		laeuferin: "Läuferin",
		archivar: "Archivar",
		waechter: "Wächter",
		jaeger: "Jäger"
	}[f.characterId] ?? f.characterId;
}
function push(frames, state, frame) {
	frames.push({
		...frame,
		state: clone(state)
	});
}
function livingCores(f) {
	return f.cores.filter((c) => c.points > 0);
}
function killBody(state, side) {
	if (state.fighters[side].body > 0) return false;
	state.over = true;
	state.winner = other(side);
	state.winReason = "Körper";
	return true;
}
function killEcho(state, side) {
	if (livingCores(state.fighters[side]).length > 0) return false;
	state.over = true;
	state.winner = other(side);
	state.winReason = "Echo";
	return true;
}
function gainBruch(state, f, amount, plan) {
	let n = amount;
	if (n <= 0) return 0;
	if (f.armorId === "ketten" && !f.ketteUsed) {
		n = Math.max(0, n - 1);
		f.ketteUsed = true;
	}
	if (plan?.reaction === "stabilize" && n >= 2 && f.energy >= 1) {
		n -= 1;
		f.energy -= 1;
		f.stabilizeNext = true;
		note(state, `${name(f)} stabilisiert und verhindert 1 Bruch.`);
	}
	if (f.braceLeft > 0 && n > 0) {
		const prevented = Math.min(f.braceLeft, n, 2);
		n -= prevented;
		f.braceLeft -= prevented;
		if (prevented) note(state, `${name(f)} bricht die Regel und hält ${prevented} Bruch ab.`);
	}
	f.bruch = Math.min(f.bruchMax, f.bruch + n);
	if (f.bruch >= f.bruchMax) f.collapse = true;
	return n;
}
function hurt(state, f, amount) {
	const dealt = Math.max(0, amount);
	f.body = Math.max(0, f.body - dealt);
	return dealt;
}
function tickStatuses(f, kinds) {
	f.statuses = f.statuses.map((s) => kinds.includes(s.kind) ? {
		...s,
		rounds: s.rounds - 1
	} : s).filter((s) => s.rounds > 0);
}
function beginRound(input) {
	const state = clone(input);
	if (state.over) return {
		state,
		line: "Das Duell ist entschieden."
	};
	state.round += 1;
	const lines = [];
	for (const side of ["A", "B"]) {
		const f = state.fighters[side];
		const gain = f.stabilizeNext ? 1 : 2;
		f.stabilizeNext = false;
		f.energy = Math.min(f.energyMax, f.energy + gain);
		f.guardBonus = 0;
		f.braceLeft = 0;
		f.predictStrike = false;
		f.ketteUsed = false;
		f.spiegelUsed = false;
		f.leatherUsed = false;
		f.ignoreUsed = false;
		f.pursued = false;
		f.moved = false;
		for (const echo of f.echoes) echo.used = false;
		tickStatuses(f, [
			"bound",
			"confused",
			"open",
			"guarded"
		]);
		lines.push(`${name(f)} +${gain} Energie`);
	}
	state.markers = state.markers.map((m) => ({
		...m,
		duration: m.duration - 1
	})).filter((m) => m.duration > 0);
	state.updatedRound = state.round;
	const line = `Runde ${state.round}. ${lines.join(" · ")}.`;
	note(state, line);
	return {
		state,
		line
	};
}
function spendEchoSecure(state, f, echo, plan) {
	if (echo.charges > 0) return false;
	if (plan?.reaction === "secure" && f.energy >= 2) {
		f.energy -= 2;
		echo.charges = 1;
		gainBruch(state, f, 1, null);
		note(state, `${name(f)} sichert ein Echo und nimmt 1 Bruch.`);
		return true;
	}
	return false;
}
function dropDeadEchoes(state, f, plan) {
	const kept = [];
	for (const echo of f.echoes) {
		if (echo.charges <= 0) {
			if (spendEchoSecure(state, f, echo, plan)) kept.push(echo);
			continue;
		}
		kept.push(echo);
	}
	f.echoes = kept;
}
function ownEcho(f, id) {
	if (!id) return f.echoes[0];
	return f.echoes.find((e) => e.id === id) ?? f.echoes[0];
}
function applyItem(state, f, foe, plan) {
	if (!plan.itemId) return;
	const item = f.items.find((i) => i.id === plan.itemId && !i.spent);
	if (!item) return;
	item.spent = true;
	if (item.id === "heil") {
		f.body = Math.min(f.bodyMax, f.body + 4);
		removeStatus(f, "wounded");
		note(state, `${name(f)} nimmt das Heilmittel. +4 Körper.`);
	} else if (item.id === "zelle") {
		f.energy = Math.min(f.energyMax, f.energy + 3);
		note(state, `${name(f)} setzt die Energiezelle ein.`);
	} else if (item.id === "binde") {
		f.bruch = Math.max(0, f.bruch - 2);
		if (f.bruch < f.bruchMax) f.collapse = false;
		addStatus(f, "bound", 2);
		note(state, `${name(f)} bindet den Bruch und wird gebunden.`);
	} else if (item.id === "splitter") {
		const echo = ownEcho(f, plan.echoId);
		if (echo) {
			echo.charges = Math.min(3, echo.charges + 2);
			echo.used = true;
			note(state, `${name(f)} speist ein Echo mit dem Splitter.`);
		}
	} else if (item.id === "blend") {
		if (hasStatus(foe, "confused")) gainBruch(state, foe, 1, null);
		else addStatus(foe, "confused", 2);
		note(state, `${name(f)} wirft Blendpulver.`);
	}
}
function freeNeighbor(f, foe, awayFrom) {
	const options = neighbors(f.field).filter((n) => n !== foe.field);
	if (!options.length) return null;
	if (awayFrom == null) return options[0];
	options.sort((a, b) => distance(b, awayFrom) - distance(a, awayFrom));
	return options[0];
}
function shift(state, f, foe, dest) {
	if (dest === foe.field) return false;
	const trapped = foe.echoes.find((e) => e.kind === "trap" && e.field === dest && e.charges > 0);
	f.field = dest;
	f.moved = true;
	if (foe.characterId === "jaeger") foe.pursued = true;
	if (trapped && !(f.characterId === "laeuferin" && !f.ignoreUsed)) {
		trapped.charges -= 1;
		trapped.used = true;
		hurt(state, f, 2);
		gainBruch(state, f, 1, null);
		note(state, `${name(f)} läuft in eine Falle.`);
		dropDeadEchoes(state, foe, null);
	} else if (trapped && f.characterId === "laeuferin") f.ignoreUsed = true;
	return true;
}
function leaveField(state, f, plan) {
	const marker = markerAt(state, f.field);
	if (marker?.kind === "rift") {
		gainBruch(state, f, 1, plan);
		marker.duration -= 1;
		note(state, `${name(f)} reißt sich vom Riss los.`);
	}
	const rift = [...state.fighters.A.echoes, ...state.fighters.B.echoes].find((e) => e.kind === "rift" && e.field === f.field && e.charges > 0 && e.owner !== f.side);
	if (rift) {
		gainBruch(state, f, 1, plan);
		rift.charges -= 1;
		rift.used = true;
	}
}
function doMove(state, f, foe, plan, steps, dest) {
	const path = shortestPath(f.field, dest, foe.field);
	if (!path || path.length - 1 > steps || path.length < 2) {
		note(state, `${name(f)} findet keinen Weg.`);
		return;
	}
	if (f.armorId === "leder" && !f.leatherUsed && plan.energy > 0) {
		f.energy = Math.min(f.energyMax, f.energy + 1);
		f.leatherUsed = true;
	}
	if (markerAt(state, f.field)?.kind === "bind" && plan.energy <= 0 && f.characterId !== "laeuferin") {
		note(state, `${name(f)} ist gefesselt und kommt nicht frei.`);
		return;
	}
	leaveField(state, f, plan);
	const land = path[path.length - 1];
	shift(state, f, foe, land);
	if (plan.energy >= 2 || plan.ability && f.characterId === "laeuferin") {
		const mirror = markerAt(state, f.field);
		let charges = 1;
		if (mirror?.kind === "mirror") {
			charges += 1;
			state.markers = state.markers.filter((m) => m.id !== mirror.id);
		}
		pushEcho(state, {
			owner: f.side,
			kind: "move",
			field: f.field,
			charges: Math.min(3, charges)
		});
		note(state, `${name(f)} hinterlässt ein Bewegungs-Echo auf Feld ${f.field}.`);
	}
	note(state, `${name(f)} geht nach Feld ${f.field}.`);
	if (f.characterId === "laeuferin") f.flank = true;
}
function attackEchoBonus(f) {
	const echo = f.echoes.find((e) => e.kind === "attack" && e.field === f.field && e.charges > 0);
	if (!echo) return {
		raw: 0,
		bruch: 0,
		echo: false
	};
	echo.used = true;
	return {
		raw: 1,
		bruch: echo.charges >= 2 ? 1 : 0,
		echo: true
	};
}
function guardEchoSoak(f) {
	const echo = f.echoes.find((e) => e.kind === "guard" && e.field === f.field && e.charges > 0);
	if (!echo) return {
		dmg: 0,
		bruch: 0
	};
	echo.used = true;
	return {
		dmg: 2,
		bruch: echo.charges >= 2 ? 1 : 0
	};
}
function resolveAttack(state, attacker, defender, plan, defenderPlan, opts) {
	const aStats = liveStats(attacker);
	const dStats = liveStats(defender);
	const range = plan.ability && attacker.characterId === "brecher" ? 1 : aStats.range;
	const dist = distance(attacker.field, defender.field);
	const blockedByBarrier = pathInteriors(attacker.field, defender.field).some((field) => [...attacker.echoes, ...defender.echoes].some((e) => e.kind === "barrier" && e.field === field && e.charges > 0));
	if (attacker.weaponId === "bogen" && hasStatus(attacker, "bound")) {
		note(state, `${name(attacker)} kann gebunden den Bogen nicht spannen.`);
		return {
			hit: false,
			ended: false
		};
	}
	if (dist > range || attacker.weaponId === "kurzschwert" && blockedByBarrier) {
		pushEcho(state, {
			owner: attacker.side,
			kind: "attack",
			field: attacker.field,
			charges: 1
		});
		note(state, `${name(attacker)} verfehlt. Das Ziel ist außer Reichweite, das Echo bleibt.`);
		return {
			hit: false,
			ended: false
		};
	}
	let attack = aStats.weapon + aStats.kraftB + plan.energy + opts.attackMod + (attacker.pursued ? 1 : 0);
	const marked = defender.marked && attacker.characterId === "jaeger";
	if (marked) attack += 2;
	let flankArmor = 0;
	if (attacker.characterId === "laeuferin" && attacker.flank) {
		attack += 2;
		flankArmor = 2;
	}
	const echoB = attackEchoBonus(attacker);
	let defense = 2 + dStats.schutzB + dStats.moveB;
	if (attacker.weaponId === "bogen") defense -= Math.min(dStats.moveB, 1);
	if (markerAt(state, defender.field)?.kind === "mist" || defender.echoes.some((e) => e.kind === "mist" && e.field === defender.field && e.charges > 0)) defense += 2;
	if (defender.characterId === "archivar" && defender.echoes.some((e) => e.field === defender.field && e.charges > 0)) defense += 2;
	if (echoB.echo && defender.armorId === "spiegel" && !defender.spiegelUsed) {
		defense += 1;
		defender.spiegelUsed = true;
	}
	const die = d6(state);
	const hit = die + attack >= defense;
	const diceNote = `Würfel ${die}. Angriff ${attack} gegen Verteidigung ${defense}.`;
	if (!hit) {
		if (attacker.weaponId === "hammer") {
			gainBruch(state, attacker, 1, plan);
			note(state, `${name(attacker)} verfehlt mit dem Hammer und nimmt 1 Bruch. ${diceNote}`);
		} else note(state, `${name(attacker)} verfehlt. ${diceNote}`);
		return {
			hit: false,
			ended: false
		};
	}
	const energyRaw = plan.energy >= 3 ? 2 : plan.energy >= 1 ? 1 : 0;
	const energyBruch = plan.energy >= 2 ? 1 : 0;
	let ignore = opts.ignoreSchutz + (marked ? 2 : 0) + (flankArmor ? 2 : 0);
	const brand = markerAt(state, defender.field)?.kind === "brand" ? 1 : 0;
	let raw = aStats.weapon + aStats.kraftB + energyRaw + echoB.raw + brand + opts.rawMod + (flankArmor ? 2 : 0) - (dist === 0 && attacker.weaponId === "speer" ? 1 : 0);
	const armorCut = flankArmor + (marked ? 1 : 0);
	let end = Math.max(1, raw - Math.max(0, dStats.schutzB - ignore) - Math.max(0, aArmor(defender) - armorCut));
	if (blockedByBarrier) end = Math.max(0, end - 2);
	const soak = guardEchoSoak(defender);
	end = Math.max(0, end - soak.dmg);
	const guarded = defender.statuses.find((s) => s.kind === "guarded");
	let bruchMod = energyBruch + echoB.bruch - soak.bruch;
	if (guarded) {
		end = Math.max(0, end - (guarded.power || 3));
		bruchMod -= 1;
		removeStatus(defender, "guarded");
	}
	const fieldGuard = markerAt(state, defender.field);
	if (fieldGuard?.kind === "guard") {
		end = Math.max(0, end - 2);
		state.markers = state.markers.filter((m) => m.id !== fieldGuard.id);
	}
	if (isOpen(defender)) {
		end += 1;
		bruchMod += 1;
	}
	const crit = die === 6 && !opts.noCrit;
	if (crit) {
		end *= 2;
		bruchMod += 1;
	}
	if (attacker.weaponId === "hammer") bruchMod += 1;
	if (attacker.characterId === "brecher" && end >= 5) bruchMod += 1;
	if (plan.ability && attacker.characterId === "brecher") {
		removeStatus(defender, "guarded");
		const shield = defender.echoes.find((e) => e.kind === "guard");
		if (shield) shield.charges = Math.max(0, shield.charges - 1);
	}
	let dodgedAll = false;
	if (defenderPlan?.reaction === "dodge" && defenderPlan.action === "move" && defender.energy >= 2) {
		defender.energy -= 2;
		const away = freeNeighbor(defender, attacker, attacker.field);
		if (away != null) {
			leaveField(state, defender, defenderPlan);
			shift(state, defender, attacker, away);
			if (distance(attacker.field, defender.field) > range) {
				dodgedAll = true;
				end = 0;
				bruchMod = 0;
			} else end = Math.max(0, end - 2);
		}
		note(state, `${name(defender)} weicht aus.`);
	}
	if (!dodgedAll && !defender.sheltered && end > 0) {
		const cut = defender.characterId === "archivar" ? 6 : defender.characterId === "jaeger" ? 4 : 0;
		if (cut > 0) {
			const applied = Math.min(cut, end);
			end -= applied;
			defender.sheltered = true;
			if (defender.characterId === "archivar") {
				pushEcho(state, {
					owner: defender.side,
					kind: "guard",
					field: defender.field,
					charges: 2
				});
				note(state, `${name(defender)} speichert den ersten Treffer. −${applied} Körper, Schutz-Echo.`);
			} else note(state, `${name(defender)} gibt dem ersten Treffer nach. −${applied} Körper.`);
		}
	}
	const dealt = dodgedAll ? 0 : hurt(state, defender, end);
	const bruch = dodgedAll ? 0 : gainBruch(state, defender, Math.max(0, bruchMod), defenderPlan);
	if (marked && !dodgedAll) pushEcho(state, {
		owner: attacker.side,
		kind: "attack",
		field: attacker.field,
		charges: 2
	});
	defender.marked = false;
	if (crit) pushEcho(state, {
		owner: attacker.side,
		kind: "attack",
		field: attacker.field,
		charges: 2
	});
	if (attacker.weaponId === "kurzschwert" && !dodgedAll) {
		const back = freeNeighbor(attacker, defender, defender.field);
		if (back != null) attacker.field = back;
	}
	if (attacker.weaponId === "kette" && !dodgedAll && attacker.energy >= 1 && defender.artifactId !== "anker" && defender.toolId !== "anker") {
		const closer = neighbors(defender.field).filter((n) => n !== attacker.field && distance(n, attacker.field) < distance(defender.field, attacker.field)).sort((a, b) => distance(a, attacker.field) - distance(b, attacker.field))[0];
		if (closer != null && closer !== attacker.field) {
			attacker.energy -= 1;
			defender.field = closer;
			note(state, `${name(attacker)} zieht ${name(defender)} heran.`);
		}
	}
	note(state, `${name(attacker)} trifft ${name(defender)}${opts.tag}. ${diceNote} ${dealt} Körper, ${bruch} Bruch${crit ? ". Kritisch" : ""}.`);
	dropDeadEchoes(state, defender, defenderPlan);
	if (killBody(state, defender.side)) return {
		hit: true,
		ended: true
	};
	if (defenderPlan?.reaction === "riposte" && defenderPlan.action === "attack" && defender.energy >= 2 && defender.body > 0) {
		defender.energy -= 2;
		if (resolveAttack(state, defender, attacker, {
			...defenderPlan,
			energy: 0,
			ability: false
		}, null, {
			rawMod: -2,
			attackMod: 0,
			ignoreSchutz: 0,
			noCrit: true,
			tag: " im Gegenstoß"
		}).ended) return {
			hit: true,
			ended: true
		};
	}
	return {
		hit: true,
		ended: false
	};
}
function aArmor(f) {
	return byId(ARMORS, f.armorId).value;
}
function doGuard(state, f, plan) {
	if (plan.ability && f.characterId === "waechter") {
		placeMarker(state, f.side, "guard", f.field, 1);
		f.guardBonus += 1;
		note(state, `${name(f)} sperrt das Feld und steht fester.`);
		return;
	}
	const power = plan.energy >= 1 ? 4 : 3;
	addStatus(f, "guarded", 1, power);
	if (plan.energy >= 2) {
		const bad = f.statuses.find((s) => s.kind === "wounded" || s.kind === "bound" || s.kind === "confused");
		if (bad) removeStatus(f, bad.kind);
	}
	if (plan.energy >= 3) {
		pushEcho(state, {
			owner: f.side,
			kind: "guard",
			field: f.field,
			charges: 2
		});
		note(state, `${name(f)} steht geschützt und setzt ein Schutz-Echo.`);
	} else note(state, `${name(f)} steht geschützt. Nächster Treffer −${power}.`);
}
function crackCore(state, attacker, defender, points) {
	const target = defender.cores.filter((c) => c.revealed && c.points > 0)[0] ?? null;
	if (!target) return false;
	target.points = Math.max(0, target.points - points);
	note(state, `${name(attacker)} bricht ein Kern-Echo. Noch ${target.points} ${target.points === 1 ? "Punkt" : "Punkte"}.`);
	if (target.points === 0) {
		defender.energyMax = Math.max(3, defender.energyMax - 1);
		defender.energy = Math.min(defender.energy, defender.energyMax);
		gainBruch(state, defender, 1, null);
		addStatus(defender, "open", 1);
		note(state, `Ein Kern von ${name(defender)} zerbricht.`);
		if (killEcho(state, defender.side)) return true;
	}
	return false;
}
function doInfluence(state, f, foe, plan) {
	const dist = distance(f.field, foe.field);
	const inReach = dist <= influenceRange(state, f);
	if (inReach) foe.cores.forEach((c) => c.revealed = true);
	if (plan.ability && f.characterId === "archivar") {
		if (f.echoes.length < 2) pushEcho(state, {
			owner: f.side,
			kind: "guard",
			field: f.field,
			charges: 2
		});
		const echoes = f.echoes.slice(0, 2);
		for (const echo of echoes) {
			echo.charges = Math.min(3, echo.charges + 1);
			echo.used = true;
		}
		note(state, `${name(f)} verbindet die eigenen Echos.`);
		return false;
	}
	if (plan.ability && f.characterId === "jaeger") {
		if (dist <= 3) {
			foe.marked = true;
			note(state, `${name(f)} markiert ${name(foe)}.`);
		} else note(state, `${name(f)} verliert die Markierung aus den Augen.`);
		return false;
	}
	if (plan.influence === "kern" && plan.energy >= 1 && inReach) {
		if (crackCore(state, f, foe, plan.energy >= 3 ? 2 : 1)) return true;
	} else if (plan.influence === "weaken" && inReach) {
		const loss = plan.energy >= 3 ? 2 : 1;
		const echo = foe.echoes.find((e) => e.charges > 0);
		if (echo) {
			echo.charges = Math.max(0, echo.charges - loss);
			echo.used = true;
			note(state, `${name(f)} schwächt ein Echo von ${name(foe)}.`);
			dropDeadEchoes(state, foe, null);
		} else if (f.toolId === "brecheisen" || f.artifactId === "brecheisen") {
			const marker = state.markers.find((m) => m.field === foe.field && (m.kind === "guard" || m.kind === "mist"));
			if (marker) {
				state.markers = state.markers.filter((m) => m.id !== marker.id);
				note(state, `${name(f)} bricht einen Feldmarker auf.`);
			}
		}
	} else if (plan.influence === "convert" || plan.freeConvert) {
		const echo = ownEcho(f, plan.echoId);
		const next = echo ? CONVERT[echo.kind] : void 0;
		if (echo && next && (plan.energy >= 1 || plan.freeConvert)) {
			if (plan.freeConvert) f.convertReady = false;
			echo.kind = next;
			echo.charges = Math.max(1, echo.charges - (plan.freeConvert ? 0 : 1));
			echo.used = true;
			if (next === "barrier") echo.ttl = 2;
			note(state, `${name(f)} wandelt ein Echo in ${ECHO_LABEL[next]}.`);
		}
	} else {
		let charges = 1 + (plan.energy >= 2 ? 1 : 0);
		if (f.characterId === "archivar" && !plan.itemId) charges += 1;
		const mirror = markerAt(state, f.field);
		if (mirror?.kind === "mirror") {
			charges += 1;
			state.markers = state.markers.filter((m) => m.id !== mirror.id);
		}
		pushEcho(state, {
			owner: f.side,
			kind: "influence",
			field: f.field,
			charges: Math.min(3, charges)
		});
		note(state, `${name(f)} legt ein Einfluss-Echo auf Feld ${f.field}.`);
	}
	if (plan.energy >= 2 && plan.influence !== "spur") {
		const echo = f.echoes[0];
		if (echo) {
			echo.charges = Math.min(3, echo.charges + 1);
			echo.used = true;
		}
	}
	return false;
}
function perform(state, side, plan, foePlan) {
	const f = state.fighters[side];
	const foe = state.fighters[other(side)];
	if (f.body <= 0) return {
		ended: true,
		tone: "win",
		title: `${name(f)} fällt`,
		detail: "Die Aktion verfällt.",
		dice: null
	};
	if (plan.energy > f.energy) plan.energy = f.energy;
	f.energy -= plan.energy;
	if (plan.ability) f.abilityRound = state.round;
	applyItem(state, f, foe, plan);
	if (plan.mist && (f.toolId === "rauch" || f.artifactId === "rauch") && f.energy >= 2) {
		f.energy -= 2;
		placeMarker(state, f.side, "mist", f.field, 2);
		note(state, `${name(f)} öffnet die Rauchkapsel.`);
	}
	if (plan.action === "attack") {
		const result = resolveAttack(state, f, foe, plan, foePlan, {
			rawMod: plan.ability && f.characterId === "brecher" ? 2 : 0,
			attackMod: 0,
			ignoreSchutz: 0,
			noCrit: false,
			tag: plan.ability ? " mit Aufbrechen" : ""
		});
		const detail = state.log[0] ?? "Angriff.";
		return {
			ended: result.ended || state.over,
			tone: result.hit ? "hit" : "miss",
			title: result.hit ? `${name(f)} trifft` : `${name(f)} verfehlt`,
			detail,
			dice: null
		};
	}
	if (plan.action === "guard") {
		doGuard(state, f, plan);
		return {
			ended: false,
			tone: "guard",
			title: `${name(f)} schützt sich`,
			detail: state.log[0] ?? "",
			dice: null
		};
	}
	if (plan.action === "move") {
		const steps = moveSteps(f, plan.energy, plan.ability);
		const dest = plan.targetField ?? f.field;
		if (!reachable(f.field, steps, foe.field).includes(dest)) note(state, `${name(f)} kommt nicht auf Feld ${dest}.`);
		else doMove(state, f, foe, plan, steps, dest);
		if (killBody(state, f.side)) return {
			ended: true,
			tone: "win",
			title: `${name(f)} fällt`,
			detail: state.log[0] ?? "",
			dice: null
		};
		return {
			ended: state.over,
			tone: "move",
			title: `${name(f)} bewegt sich`,
			detail: state.log[0] ?? "",
			dice: null
		};
	}
	return {
		ended: doInfluence(state, f, foe, plan) || state.over,
		tone: "echo",
		title: `${name(f)} nimmt Einfluss`,
		detail: state.log[0] ?? "",
		dice: null
	};
}
function endRound(state) {
	for (const side of ["A", "B"]) {
		const f = state.fighters[side];
		if (hasStatus(f, "wounded")) {
			hurt(state, f, 1);
			note(state, `${name(f)} blutet. −1 Körper.`);
		}
		tickStatuses(f, ["wounded"]);
		f.echoes = f.echoes.flatMap((echo) => {
			let charges = echo.charges;
			let ttl = echo.ttl;
			if (!echo.used) charges -= 1;
			if (ttl > 0) ttl -= 1;
			if (charges <= 0 || echo.kind === "barrier" && ttl === 0 && echo.ttl > 0) return [];
			return [{
				...echo,
				charges,
				ttl
			}];
		});
	}
	for (const side of ["A", "B"]) {
		if (killBody(state, side)) return;
		if (killEcho(state, side)) return;
	}
	const losers = ["A", "B"].filter((s) => state.fighters[s].collapse && state.fighters[s].bruch >= state.fighters[s].bruchMax);
	if (losers.length === 1) {
		state.over = true;
		state.winner = other(losers[0]);
		state.winReason = "Bruch";
		note(state, `${name(state.fighters[losers[0]])} bricht zusammen.`);
	} else if (losers.length === 2) {
		state.over = true;
		state.winner = null;
		state.winReason = "Bruch";
		note(state, "Beide Kämpfer brechen zusammen.");
	}
	if (!state.over) {
		state.startSide = other(state.startSide);
		removeRoundFlags(state);
	}
}
function removeRoundFlags(state) {
	for (const side of ["A", "B"]) {
		state.fighters[side].moved = false;
		state.fighters[side].pursued = false;
	}
}
function resolveRound(input, planA, planB) {
	const state = clone(input);
	const plans = {
		A: clone(planA),
		B: clone(planB)
	};
	const frames = [];
	for (const side of ["A", "B"]) {
		const f = state.fighters[side];
		const plan = plans[side];
		const foePlan = plans[other(side)];
		if (plan.prediction && f.pattern[plan.prediction] >= 3) {
			if (foePlan.action === plan.prediction) {
				f.predictStrike = true;
				f.pattern[plan.prediction] = 0;
				gainBruch(state, state.fighters[other(side)], 1, null);
				note(state, `${name(f)} liest ${foePlan.action} richtig.`);
			} else {
				f.pattern = {
					attack: 0,
					guard: 0,
					move: 0,
					influence: 0
				};
				const foe = state.fighters[other(side)];
				foe.energy = Math.min(foe.energyMax, foe.energy + 1);
				note(state, `${name(f)} liest falsch. Die Muster fallen.`);
			}
		}
	}
	for (const side of ["A", "B"]) {
		const f = state.fighters[side];
		const plan = plans[side];
		if (f.lastAction === plan.action) {
			const foe = state.fighters[other(side)];
			foe.pattern[plan.action] = Math.min(3, foe.pattern[plan.action] + 1);
		}
		f.lastAction = plan.action;
		if (plan.ruleBreak && f.ruleBreak) {
			f.ruleBreak = false;
			if (plan.ruleBreak === "refund" && plan.energy > 0) {
				plan.energy -= 1;
				note(state, `${name(f)} nimmt eine Energiestufe zurück.`);
			}
			if (plan.ruleBreak === "brace") f.braceLeft = 2;
			if (plan.ruleBreak === "retarget" && plan.retargetField) plan.targetField = plan.retargetField;
		}
		if (plan.mask && f.maskReady && plan.retargetField) {
			f.maskReady = false;
			plan.targetField = plan.retargetField;
			note(state, `${name(f)} verschiebt das Ziel mit der Maske.`);
		}
		if (plan.zeitnadel && f.nadelReady) f.nadelReady = false;
		else plan.zeitnadel = false;
		if (plan.freeConvert && !f.convertReady) plan.freeConvert = false;
	}
	const order = orderSides(state, plans);
	push(frames, state, {
		kicker: `Runde ${state.round} · Aufdecken`,
		title: `${label(plans[order[0]].action)} vor ${label(plans[order[1]].action)}`,
		detail: `${name(state.fighters[order[0]])} handelt zuerst. Aktionswert ${actionValue(state.fighters[order[0]], plans[order[0]])} gegen ${actionValue(state.fighters[order[1]], plans[order[1]])}.`,
		tone: "idle",
		focus: [state.fighters[order[0]].field, state.fighters[order[1]].field],
		actor: order[0],
		dice: null
	});
	for (const side of order) {
		if (state.over) break;
		const result = perform(state, side, plans[side], plans[other(side)]);
		const die = extractDie(result.detail);
		push(frames, state, {
			kicker: `Runde ${state.round} · ${label(plans[side].action)}`,
			title: result.title,
			detail: result.detail,
			tone: state.over ? "win" : result.tone,
			focus: [state.fighters[side].field, state.fighters[other(side)].field],
			actor: side,
			dice: die
		});
		if (result.ended || state.over) break;
	}
	if (!state.over) {
		endRound(state);
		push(frames, state, {
			kicker: `Runde ${state.round} · Ende`,
			title: state.over ? winTitle(state) : "Die Spur kühlt ab",
			detail: state.over ? winDetail(state) : "Ungenutzte Echos verlieren Ladung. Der Start wechselt.",
			tone: state.over ? "win" : "break",
			focus: [state.fighters.A.field, state.fighters.B.field],
			actor: null,
			dice: null
		});
	} else push(frames, state, {
		kicker: `Runde ${state.round} · Entscheidung`,
		title: winTitle(state),
		detail: winDetail(state),
		tone: "win",
		focus: [state.fighters.A.field, state.fighters.B.field],
		actor: state.winner,
		dice: null
	});
	return frames;
}
function orderSides(state, plans) {
	const score = (side) => actionValue(state.fighters[side], plans[side]);
	const first = state.startSide;
	const pair = [first, other(first)];
	pair.sort((a, b) => {
		const va = score(a);
		const vb = score(b);
		if (va !== vb) return vb - va;
		if (plans[a].energy !== plans[b].energy) return plans[a].energy - plans[b].energy;
		const ta = liveStats(state.fighters[a]).tempo;
		const tb = liveStats(state.fighters[b]).tempo;
		if (ta !== tb) return tb - ta;
		if (state.fighters[a].body !== state.fighters[b].body) return state.fighters[a].body - state.fighters[b].body;
		const ra = d6(state);
		return d6(state) - ra;
	});
	return [pair[0], pair[1]];
}
function label(action) {
	if (action === "attack") return "Angriff";
	if (action === "guard") return "Schutz";
	if (action === "move") return "Bewegung";
	return "Einfluss";
}
function extractDie(detail) {
	const match = detail.match(/Würfel (\d)/);
	return match ? Number(match[1]) : null;
}
function winTitle(state) {
	if (!state.winner) return "Beide brechen";
	return `${name(state.fighters[state.winner])} siegt`;
}
function winDetail(state) {
	if (state.winReason === "Körper") return "Der Körper des Gegners ist auf 0.";
	if (state.winReason === "Echo") return "Alle drei Kern-Echos sind zerstört.";
	if (state.winReason === "Bruch") return "Das Bruchmaximum ist erreicht, die letzte Runde ist vorbei.";
	return "Das Duell endet.";
}
function preparePlan(state, side, plan) {
	const next = clone(plan);
	const f = state.fighters[side];
	const foe = state.fighters[other(side)];
	const stats = liveStats(f);
	if (next.ability) {
		const cost = f.characterId === "brecher" ? 3 : f.characterId === "laeuferin" || f.characterId === "waechter" ? 2 : f.characterId === "jaeger" ? 1 : 3;
		const action = f.characterId === "brecher" ? "attack" : f.characterId === "laeuferin" ? "move" : f.characterId === "waechter" ? "guard" : "influence";
		if (f.energy < cost || f.abilityRound === state.round) next.ability = false;
		else {
			next.action = action;
			next.energy = cost;
		}
	}
	next.energy = Math.max(0, Math.min(3, next.energy, f.energy));
	if (next.itemId && !f.items.some((i) => i.id === next.itemId && !i.spent)) next.itemId = null;
	if (next.prediction && f.pattern[next.prediction] < 3) next.prediction = null;
	if (next.ruleBreak && !f.ruleBreak) next.ruleBreak = null;
	if (next.zeitnadel && !f.nadelReady) next.zeitnadel = false;
	if (next.mask && !f.maskReady) next.mask = false;
	if (next.freeConvert && !f.convertReady) next.freeConvert = false;
	if (!f.toolId.includes("rauch") && f.artifactId !== "rauch" && f.toolId !== "rauch") next.mist = false;
	if (next.action === "attack") {
		const range = next.ability && f.characterId === "brecher" ? 1 : stats.range;
		if ((distance(f.field, foe.field) > range || f.weaponId === "bogen" && hasStatus(f, "bound")) && !next.ability) {
			next.action = "guard";
			next.targetField = f.field;
		} else next.targetField = foe.field;
	}
	if (next.action === "move") {
		const steps = moveSteps(f, next.energy, next.ability);
		const legal = reachable(f.field, steps, foe.field);
		if (next.targetField == null || !legal.includes(next.targetField)) next.targetField = legal[0] ?? null;
		if (next.targetField == null) {
			next.action = "guard";
			next.energy = 0;
			next.ability = false;
		}
	}
	if (next.action === "guard") next.targetField = f.field;
	if (next.action === "influence") {
		if (next.influence === "kern" && (next.energy < 1 || distance(f.field, foe.field) > influenceRange(state, f))) next.influence = "spur";
		next.targetField = foe.field;
	}
	if (next.reaction) {
		const cost = next.reaction === "stabilize" ? 1 : 2;
		if (f.energy - next.energy < cost) next.reaction = null;
	}
	return next;
}
function useStone(input, side) {
	const state = clone(input);
	const f = state.fighters[side];
	if (!(f.toolId === "bruchstein" || f.artifactId === "bruchstein") || f.stoneRound === state.round || f.bruch >= f.bruchMax) return state;
	f.stoneRound = state.round;
	gainBruch(state, f, 1, null);
	f.energy = Math.min(f.energyMax, f.energy + 2);
	note(state, `${name(f)} drückt den Bruchstein. +2 Energie, +1 Bruch.`);
	return state;
}
function bestPattern(state, side) {
	const pattern = state.fighters[side].pattern;
	return Object.keys(pattern).filter((key) => pattern[key] >= 3)[0] ?? null;
}
function choosePlan(state, side, difficulty) {
	const me = state.fighters[side];
	const foe = state.fighters[other(side)];
	const stats = liveStats(me);
	const foeStats = liveStats(foe);
	const dist = distance(me.field, foe.field);
	const candidates = [];
	const energyCap = Math.min(3, me.energy);
	for (let energy = 0; energy <= energyCap; energy++) {
		if (dist <= stats.range && !(me.weaponId === "bogen" && me.statuses.some((s) => s.kind === "bound"))) candidates.push({
			...emptyPlan(),
			action: "attack",
			energy,
			targetField: foe.field
		});
		candidates.push({
			...emptyPlan(),
			action: "guard",
			energy,
			targetField: me.field
		});
		const steps = moveSteps(me, energy, false);
		for (const field of reachable(me.field, steps, foe.field)) candidates.push({
			...emptyPlan(),
			action: "move",
			energy,
			targetField: field
		});
		candidates.push({
			...emptyPlan(),
			action: "influence",
			energy,
			influence: "spur",
			targetField: me.field
		});
		if (energy >= 1 && dist <= 3) candidates.push({
			...emptyPlan(),
			action: "influence",
			energy,
			influence: "kern",
			targetField: foe.field
		});
	}
	if (me.characterId === "brecher" && me.energy >= 3 && dist <= 1 && me.abilityRound !== state.round) candidates.push({
		...emptyPlan(),
		action: "attack",
		energy: 3,
		ability: true,
		targetField: foe.field
	});
	if (me.characterId === "laeuferin" && me.energy >= 2 && me.abilityRound !== state.round) for (const field of reachable(me.field, 2, foe.field)) candidates.push({
		...emptyPlan(),
		action: "move",
		energy: 2,
		ability: true,
		targetField: field
	});
	if (me.characterId === "waechter" && me.energy >= 2 && me.abilityRound !== state.round) candidates.push({
		...emptyPlan(),
		action: "guard",
		energy: 2,
		ability: true,
		targetField: me.field
	});
	if (me.characterId === "jaeger" && me.energy >= 1 && dist <= 3 && me.abilityRound !== state.round && !foe.marked) candidates.push({
		...emptyPlan(),
		action: "influence",
		energy: 1,
		ability: true,
		influence: "spur",
		targetField: foe.field
	});
	if (me.characterId === "archivar" && me.energy >= 3 && me.echoes.length >= 2 && me.abilityRound !== state.round) candidates.push({
		...emptyPlan(),
		action: "influence",
		energy: 3,
		ability: true,
		influence: "spur",
		targetField: me.field
	});
	let best = candidates[0] ?? emptyPlan();
	let bestScore = -Infinity;
	for (const plan of candidates) {
		let score = Math.random() * (difficulty === "brutal" ? 4 : 8);
		const nextDist = plan.action === "move" && plan.targetField ? distance(plan.targetField, foe.field) : dist;
		if (plan.action === "attack") {
			score += 18 + stats.weapon + stats.kraftB + plan.energy * 2;
			if (foe.body <= foe.bodyMax * .45) score += 16;
			if (isOpen(foe)) score += 8;
			if (foe.marked) score += 10;
			if (difficulty === "brutal") score += 14;
			if (difficulty === "bedacht" && me.body < me.bodyMax * .35) score -= 8;
		}
		if (plan.action === "guard") {
			score += dist <= foeStats.range ? 12 : 2;
			if (me.body < me.bodyMax * .4) score += 18;
			if (isOpen(me) || me.bruch >= me.bruchMax - 2) score += 10;
			if (difficulty === "bedacht") score += 8;
			if (difficulty === "brutal") score -= 8;
			score -= plan.energy;
		}
		if (plan.action === "move") {
			score += (dist - nextDist) * 9;
			if (dist > stats.range) score += 16;
			if (difficulty === "bedacht" && me.body < me.bodyMax * .4) score += (nextDist - dist) * 7;
			if (plan.energy >= 2) score += 2;
		}
		if (plan.action === "influence") {
			score += stats.konB * 2;
			if (plan.influence === "kern" && foe.cores.some((c) => c.revealed)) score += 20;
			if (plan.influence === "kern") score += 6;
			if (difficulty === "taktisch") score += 7;
			if (me.echoes.length === 0 && plan.influence === "spur") score += 5;
		}
		if (plan.ability && plan.action === "attack") score += 8;
		if (plan.ability && plan.action !== "attack") score += plan.action === "guard" ? 6 : 8;
		if (me.characterId === "jaeger" && plan.ability && foeStats.schutzB + foeStats.armor >= 4) score += 16;
		if (me.characterId === "laeuferin" && me.flank && plan.action === "attack") score += 24;
		if (me.characterId === "laeuferin" && !me.flank && foeStats.schutzB + foeStats.armor >= 4 && plan.action === "move") score += 32;
		if (me.characterId === "laeuferin" && dist > stats.range && plan.action === "move") score += 12;
		if (me.characterId === "archivar" && me.body < me.bodyMax * .55 && plan.action === "guard") score += 16;
		if (me.characterId === "archivar" && plan.influence === "kern") score += 8;
		if (difficulty === "bedacht") score -= plan.energy * 1.5;
		if (score > bestScore) {
			bestScore = score;
			best = plan;
		}
	}
	const ready = preparePlan(state, side, best);
	const heal = me.items.find((i) => i.id === "heil" && !i.spent);
	const cell = me.items.find((i) => i.id === "zelle" && !i.spent);
	const brace = me.items.find((i) => i.id === "binde" && !i.spent);
	const dust = me.items.find((i) => i.id === "blend" && !i.spent);
	if (heal && me.body <= me.bodyMax * .45) ready.itemId = "heil";
	else if (brace && me.bruch >= me.bruchMax - 2) ready.itemId = "binde";
	else if (cell && me.energy <= 1) ready.itemId = "zelle";
	else if (dust && difficulty !== "bedacht" && ready.action === "attack") ready.itemId = "blend";
	if (difficulty !== "brutal") {
		if (ready.action === "move" && me.energy - ready.energy >= 2) ready.reaction = "dodge";
		else if (me.bruch >= 2 && me.energy - ready.energy >= 1) ready.reaction = "stabilize";
	} else if (ready.action === "attack" && me.energy - ready.energy >= 2) ready.reaction = "riposte";
	const predicted = bestPattern(state, side);
	if (predicted && difficulty !== "brutal") ready.prediction = predicted;
	if (me.nadelReady && difficulty === "brutal" && ready.action === "attack") ready.zeitnadel = true;
	if ((me.toolId === "rauch" || me.artifactId === "rauch") && me.energy - ready.energy >= 2 && dist <= 2) ready.mist = difficulty !== "brutal";
	return preparePlan(state, side, ready);
}
var ECHO_CLASS = {
	attack: "var(--color-accent)",
	guard: "var(--color-steel)",
	move: "var(--color-olive)",
	influence: "var(--color-soft)",
	trap: "var(--color-accent)",
	barrier: "var(--color-steel)",
	mist: "var(--color-muted)",
	rift: "var(--color-soft)"
};
function Board({ state, legal, selected, focus, shake, onPick }) {
	const marks = /* @__PURE__ */ new Map();
	for (let id = 1; id <= 7; id++) marks.set(id, { echoes: [] });
	for (const side of ["A", "B"]) for (const echo of state.fighters[side].echoes) marks.get(echo.field)?.echoes.push(echo);
	for (const marker of state.markers) {
		const slot = marks.get(marker.field);
		if (slot) slot.marker = marker.kind;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 1000 1200",
		className: `h-full w-full ${shake ? "shake" : ""}`,
		role: "img",
		"aria-label": "Spielfeld mit sieben Feldern",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "1000",
				height: "1200",
				fill: "transparent"
			}),
			EDGES.map(([a, b]) => {
				const hot = a === selected || b === selected || focus.includes(a) || focus.includes(b);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: POS[a][0],
					y1: POS[a][1],
					x2: POS[b][0],
					y2: POS[b][1],
					stroke: hot ? "var(--color-soft)" : "var(--color-line)",
					strokeWidth: hot ? 8 : 4,
					strokeLinecap: "round"
				}, `${a}-${b}`);
			}),
			[
				1,
				2,
				3,
				4,
				5,
				6,
				7
			].map((id) => {
				const [x, y] = POS[id];
				const hereA = state.fighters.A.field === id;
				const hereB = state.fighters.B.field === id;
				const fighter = hereA ? state.fighters.A : hereB ? state.fighters.B : null;
				const isLegal = legal.includes(id);
				const isSel = selected === id;
				const isFocus = focus.includes(id);
				const slot = marks.get(id);
				const fill = fighter ? fighter.side === "A" ? "var(--color-fg)" : "var(--color-accent)" : isSel ? "var(--color-soft)" : "var(--color-raised)";
				const ink = fighter?.side === "B" || isSel ? "var(--color-ink)" : "var(--color-fg)";
				const label = fighter ? fighter.characterId === "laeuferin" ? "L" : fighter.characterId === "waechter" ? "W" : fighter.characterId === "archivar" ? "A" : fighter.characterId === "brecher" ? "B" : "J" : String(id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					onClick: () => onPick?.(id),
					className: onPick ? "cursor-pointer" : "",
					role: onPick ? "button" : void 0,
					"aria-label": `Feld ${id}${fighter ? `, ${fighter.side}` : ""}`,
					children: [
						(isLegal || isFocus) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: x,
							cy: y,
							r: "58",
							fill: "none",
							stroke: isFocus ? "var(--color-fg)" : "var(--color-soft)",
							strokeWidth: "2",
							strokeDasharray: isLegal && !isFocus ? "4 6" : void 0
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: x,
							cy: y,
							r: "46",
							fill,
							stroke: "var(--color-line)",
							strokeWidth: "3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x,
							y: y + 2,
							textAnchor: "middle",
							dominantBaseline: "central",
							fill: fighter ? ink : "var(--color-fg)",
							fontFamily: "Fraunces, Palatino, serif",
							fontSize: fighter ? 28 : 26,
							fontWeight: 600,
							children: label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: x + 30,
							y: y + 34,
							textAnchor: "middle",
							fill: "var(--color-muted)",
							fontFamily: "Outfit, sans-serif",
							fontSize: "14",
							children: fighter ? id : neighbors(id).length
						}),
						slot.echoes.slice(0, 4).map((echo, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: x - 30 + index * 16,
							cy: y + 62,
							r: "6",
							fill: ECHO_CLASS[echo.kind],
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("title", { children: [
								ECHO_LABEL[echo.kind],
								" ",
								echo.charges
							] })
						}, `${echo.kind}-${index}`)),
						slot.marker && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x,
							y: y - 62,
							textAnchor: "middle",
							fill: "var(--color-muted)",
							fontFamily: "Outfit, sans-serif",
							fontSize: "13",
							children: slot.marker === "brand" ? "Brand" : slot.marker === "mist" ? "Nebel" : slot.marker === "guard" ? "Schutz" : slot.marker === "bind" ? "Fessel" : slot.marker === "rift" ? "Riss" : "Spiegel"
						})
					]
				}, id);
			})
		]
	});
}
var SAVE_KEY = "echo-bruch";
var LOG_KEY = "echo-bruch-logs";
function readLogs() {
	try {
		const raw = localStorage.getItem(LOG_KEY);
		if (!raw) return [];
		const data = JSON.parse(raw);
		return Array.isArray(data) ? data.filter((entry) => Array.isArray(entry.lines)) : [];
	} catch {
		return [];
	}
}
function storeLog(game) {
	const names = {
		A: CHARACTERS.find((c) => c.id === game.fighters.A.characterId)?.name ?? "A",
		B: CHARACTERS.find((c) => c.id === game.fighters.B.characterId)?.name ?? "B"
	};
	const winner = game.winner ? names[game.winner] : "Unentschieden";
	const entry = {
		id: `${game.seed}-${game.round}-${game.log.length}`,
		title: `${names.A} gegen ${names.B} · ${winner} · Runde ${game.round} · ${game.winReason ?? "offen"}`,
		lines: [...game.log].reverse()
	};
	const prev = readLogs().filter((item) => item.id !== entry.id);
	localStorage.setItem(LOG_KEY, JSON.stringify([entry, ...prev].slice(0, 16)));
}
function downloadText(filename, text) {
	const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function initial() {
	return {
		screen: "title",
		mode: "bot",
		difficulty: "taktisch",
		focus: "A",
		afterCover: "plan",
		setup: {
			A: suggestedSetup("jaeger", "A"),
			B: suggestedSetup("waechter", "B")
		},
		game: null,
		draft: emptyPlan(),
		locked: {},
		frames: [],
		frame: 0,
		auto: true,
		muted: false,
		codex: false,
		banner: "",
		wins: 0,
		losses: 0
	};
}
function openBattle(state, setup) {
	const begun = beginRound(createGame(setup.A, setup.B));
	return {
		...state,
		setup,
		game: begun.state,
		banner: begun.line,
		screen: state.mode === "hotseat" ? "cover" : "plan",
		afterCover: "plan",
		focus: "A",
		draft: emptyPlan(),
		locked: {},
		frames: [],
		frame: 0,
		codex: false
	};
}
function finishScenes(state) {
	const game = state.frames[state.frames.length - 1]?.state ?? state.game;
	if (!game) return state;
	if (game.over) {
		const bot = state.mode === "bot";
		return {
			...state,
			game,
			screen: "end",
			frames: [],
			wins: bot && game.winner === "A" ? state.wins + 1 : state.wins,
			losses: bot && game.winner === "B" ? state.losses + 1 : state.losses
		};
	}
	const begun = beginRound(game);
	return {
		...state,
		game: begun.state,
		banner: begun.line,
		screen: state.mode === "hotseat" ? "cover" : "plan",
		afterCover: "plan",
		focus: "A",
		draft: emptyPlan(),
		locked: {},
		frames: [],
		frame: 0
	};
}
function reduce(state, act) {
	switch (act.type) {
		case "prefs": return {
			...state,
			auto: act.auto,
			muted: act.muted,
			wins: act.wins,
			losses: act.losses,
			difficulty: act.difficulty
		};
		case "difficulty": return {
			...state,
			difficulty: act.value
		};
		case "boot": return {
			...state,
			mode: act.mode,
			focus: "A",
			screen: "roster"
		};
		case "quick": {
			const a = suggestedSetup("jaeger", "A");
			const b = botSetup(a, state.difficulty);
			b.field = 5;
			return openBattle({
				...state,
				mode: "bot"
			}, {
				A: a,
				B: b
			});
		}
		case "character": {
			const next = suggestedSetup(act.id, state.focus);
			next.field = state.setup[state.focus].field;
			return {
				...state,
				setup: {
					...state.setup,
					[state.focus]: next
				}
			};
		}
		case "kit": return {
			...state,
			screen: "kit"
		};
		case "slot": return {
			...state,
			setup: {
				...state.setup,
				[state.focus]: {
					...state.setup[state.focus],
					[act.slot]: act.id
				}
			}
		};
		case "item": {
			const current = state.setup[state.focus];
			if (current.items.includes(act.id)) return state;
			return {
				...state,
				setup: {
					...state.setup,
					[state.focus]: {
						...current,
						items: [current.items[1], act.id]
					}
				}
			};
		}
		case "field":
			if (!STARTS[state.focus].includes(act.id)) return state;
			return {
				...state,
				setup: {
					...state.setup,
					[state.focus]: {
						...state.setup[state.focus],
						field: act.id
					}
				}
			};
		case "advance":
			if (state.screen === "roster") return {
				...state,
				screen: "kit"
			};
			if (state.screen === "kit") {
				if (state.mode === "hotseat" && state.focus === "A") return {
					...state,
					screen: "cover",
					afterCover: "roster",
					focus: "B"
				};
				return {
					...state,
					screen: "deploy",
					focus: "A"
				};
			}
			if (state.screen === "deploy") {
				if (state.mode === "hotseat" && state.focus === "A") return {
					...state,
					screen: "cover",
					afterCover: "deploy",
					focus: "B"
				};
				const setup = {
					A: state.setup.A,
					B: { ...state.setup.B }
				};
				if (state.mode === "bot") {
					const bot = botSetup(setup.A, state.difficulty);
					bot.field = setup.A.field === 4 ? 3 : 5;
					setup.B = bot;
				}
				return openBattle(state, setup);
			}
			return state;
		case "back":
			if (state.screen === "roster") return {
				...state,
				screen: "title",
				focus: "A"
			};
			if (state.screen === "kit") return {
				...state,
				screen: "roster"
			};
			if (state.screen === "deploy") return {
				...state,
				screen: "kit",
				focus: state.mode === "bot" ? "A" : state.focus
			};
			return state;
		case "ready": return {
			...state,
			screen: state.afterCover,
			draft: emptyPlan()
		};
		case "draft": return {
			...state,
			draft: act.plan
		};
		case "stone":
			if (!state.game) return state;
			return {
				...state,
				game: useStone(state.game, state.focus)
			};
		case "lock": {
			if (!state.game || state.game.over) return state;
			const plan = preparePlan(state.game, state.focus, state.draft);
			if (state.mode === "bot") {
				const bot = choosePlan(state.game, "B", state.difficulty);
				return {
					...state,
					frames: resolveRound(state.game, plan, bot),
					frame: 0,
					screen: "scene",
					locked: {
						A: plan,
						B: bot
					}
				};
			}
			const locked = {
				...state.locked,
				[state.focus]: plan
			};
			if (state.focus === "A") return {
				...state,
				locked,
				screen: "cover",
				afterCover: "plan",
				focus: "B",
				draft: emptyPlan()
			};
			return {
				...state,
				locked,
				frames: resolveRound(state.game, locked.A ?? plan, plan),
				frame: 0,
				screen: "scene"
			};
		}
		case "step":
			if (state.frame < state.frames.length - 1) return {
				...state,
				frame: state.frame + 1
			};
			return finishScenes(state);
		case "skip": return finishScenes({
			...state,
			frame: Math.max(0, state.frames.length - 1)
		});
		case "auto": return {
			...state,
			auto: !state.auto
		};
		case "mute": return {
			...state,
			muted: !state.muted
		};
		case "codex": return {
			...state,
			codex: !state.codex
		};
		case "rematch": return openBattle(state, state.setup);
		case "title": return {
			...initial(),
			wins: state.wins,
			losses: state.losses,
			muted: state.muted,
			auto: state.auto,
			difficulty: state.difficulty
		};
		case "ledger": return {
			...state,
			screen: "ledger",
			codex: false
		};
		default: return state;
	}
}
var audioCtx = null;
function cue(kind, muted) {
	if (muted || typeof window === "undefined") return;
	const Ctx = window.AudioContext;
	if (!Ctx) return;
	if (!audioCtx) audioCtx = new Ctx();
	if (audioCtx.state === "suspended") audioCtx.resume();
	const osc = audioCtx.createOscillator();
	const gain = audioCtx.createGain();
	osc.connect(gain);
	gain.connect(audioCtx.destination);
	const freq = kind === "hit" ? 128 : kind === "win" ? 196 : kind === "guard" ? 240 : kind === "move" ? 180 : kind === "echo" ? 300 : 96;
	osc.type = kind === "hit" || kind === "win" ? "triangle" : "sine";
	osc.frequency.value = freq;
	const now = audioCtx.currentTime;
	gain.gain.setValueAtTime(1e-4, now);
	gain.gain.exponentialRampToValueAtTime(.04, now + .02);
	gain.gain.exponentialRampToValueAtTime(1e-4, now + .18);
	osc.start(now);
	osc.stop(now + .2);
}
var ACTION_ICON = {
	attack: Swords,
	guard: Shield,
	move: Footprints,
	influence: Orbit
};
function GameApp({ onBasis }) {
	const [duel, dispatch] = (0, import_react.useReducer)(reduce, void 0, initial);
	(0, import_react.useEffect)(() => {
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) {
			if (reduced) dispatch({
				type: "prefs",
				auto: false,
				muted: false,
				wins: 0,
				losses: 0,
				difficulty: "taktisch"
			});
			return;
		}
		try {
			const data = JSON.parse(raw);
			dispatch({
				type: "prefs",
				auto: typeof data.auto === "boolean" ? data.auto : !reduced,
				muted: Boolean(data.muted),
				wins: Number(data.wins) || 0,
				losses: Number(data.losses) || 0,
				difficulty: data.difficulty === "bedacht" || data.difficulty === "brutal" ? data.difficulty : "taktisch"
			});
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		localStorage.setItem(SAVE_KEY, JSON.stringify({
			auto: duel.auto,
			muted: duel.muted,
			wins: duel.wins,
			losses: duel.losses,
			difficulty: duel.difficulty
		}));
	}, [
		duel.auto,
		duel.muted,
		duel.wins,
		duel.losses,
		duel.difficulty
	]);
	(0, import_react.useEffect)(() => {
		if (duel.screen === "end" && duel.game?.over) storeLog(duel.game);
	}, [duel.screen, duel.game]);
	(0, import_react.useEffect)(() => {
		if (duel.screen !== "scene" || !duel.auto) return;
		const timer = window.setTimeout(() => dispatch({ type: "step" }), 1700);
		return () => window.clearTimeout(timer);
	}, [
		duel.screen,
		duel.frame,
		duel.auto,
		duel.frames.length
	]);
	(0, import_react.useEffect)(() => {
		if (duel.screen !== "scene") return;
		const beat = duel.frames[duel.frame];
		if (beat) cue(beat.tone, duel.muted);
	}, [
		duel.screen,
		duel.frame,
		duel.frames,
		duel.muted
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.key === " " && duel.screen === "scene") {
				event.preventDefault();
				dispatch({ type: "step" });
			}
			if (event.key === "Enter" && duel.screen === "plan") dispatch({ type: "lock" });
			if (duel.screen === "plan" && duel.game && event.key >= "1" && event.key <= "4") {
				const action = ACTIONS[Number(event.key) - 1].id;
				dispatch({
					type: "draft",
					plan: withAction(duel.draft, action, duel.game, duel.focus)
				});
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		duel.screen,
		duel.draft,
		duel.game,
		duel.focus
	]);
	const beat = duel.screen === "scene" ? duel.frames[duel.frame] : null;
	const view = shownState(duel, beat);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			duel.screen === "title" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
				duel,
				dispatch,
				onBasis
			}),
			duel.screen === "roster" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Roster, {
				duel,
				dispatch
			}),
			duel.screen === "kit" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kit, {
				duel,
				dispatch
			}),
			duel.screen === "cover" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
				duel,
				dispatch
			}),
			duel.screen === "end" && duel.game && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ending, {
				duel,
				dispatch
			}),
			duel.screen === "ledger" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ledger, { onBack: () => dispatch({ type: "title" }) }),
			(duel.screen === "deploy" || duel.screen === "plan" || duel.screen === "scene") && view && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Battle, {
				duel,
				view,
				beat,
				dispatch
			}),
			duel.codex && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Codex, { onClose: () => dispatch({ type: "codex" }) })
		]
	});
}
function Title({ duel, dispatch, onBasis }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-5xl flex-col justify-center gap-8 px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Endversion 1.0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "display mt-2 text-5xl sm:text-6xl",
						children: "ECHO//BRUCH"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-muted",
						children: "Plane verdeckt. Lies deinen Gegner. Hinterlasse eine Spur. Sieben Felder, vier Aktionen, drei Wege zum Sieg."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					{
						id: "bedacht",
						name: "Bedacht",
						text: "Hält Abstand, liest Muster, spielt den Wächter."
					},
					{
						id: "taktisch",
						name: "Taktisch",
						text: "Kontert dein Set und mischt Einfluss mit Druck."
					},
					{
						id: "brutal",
						name: "Rücksichtslos",
						text: "Der Brecher. Volle Energie, kein Schritt zurück."
					}
				].map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `panel p-4 text-left ${duel.difficulty === level.id ? "border-fg" : ""}`,
					onClick: () => dispatch({
						type: "difficulty",
						value: level.id
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "display text-2xl",
						children: level.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block text-sm text-muted",
						children: level.text
					})]
				}, level.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: () => {
							cue("idle", duel.muted);
							dispatch({
								type: "boot",
								mode: "bot"
							});
						},
						children: "Gegen den Bot"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => {
							cue("idle", duel.muted);
							dispatch({
								type: "boot",
								mode: "hotseat"
							});
						},
						children: "Zu zweit am Gerät"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => {
							cue("idle", duel.muted);
							dispatch({ type: "quick" });
						},
						children: "Sofort kämpfen"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => dispatch({ type: "ledger" }),
						children: "Protokolle"
					}),
					onBasis && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: onBasis,
						children: "Zur Basis"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-faint tabular-nums",
				children: [
					"Gegen den Bot: ",
					duel.wins,
					" Siege · ",
					duel.losses,
					" Niederlagen"
				]
			})
		]
	});
}
function Roster({ duel, dispatch }) {
	const current = duel.setup[duel.focus].characterId;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-6xl flex-col gap-6 px-4 py-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHead, {
			kicker: duel.focus === "A" ? "Spieler A" : "Spieler B",
			title: "Wer tritt an",
			action: "Weiter zur Ausrüstung",
			onBack: () => dispatch({ type: "back" }),
			onNext: () => dispatch({ type: "advance" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-5",
			children: CHARACTERS.map((c) => {
				const on = c.id === current;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => dispatch({
						type: "character",
						id: c.id
					}),
					className: `panel flex flex-col gap-3 p-4 text-left ${on ? "border-fg" : ""}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sigil, { id: c.id }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "display block text-2xl",
							children: c.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: c.line
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatLine, {
							label: "Kraft",
							value: c.kraft
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatLine, {
							label: "Schutz",
							value: c.schutz
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatLine, {
							label: "Bewegung",
							value: c.bewegung
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatLine, {
							label: "Kontrolle",
							value: c.kontrolle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatLine, {
							label: "Tempo",
							value: c.tempo
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: c.passive
						})
					]
				}, c.id);
			})
		})]
	});
}
function Kit({ duel, dispatch }) {
	const setup = duel.setup[duel.focus];
	const max = derivedMax(setup);
	const c = CHARACTERS.find((item) => item.id === setup.characterId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-6xl flex-col gap-5 px-4 py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHead, {
				kicker: c.name,
				title: "Ausrüstung legen",
				action: duel.mode === "hotseat" && duel.focus === "A" ? "Weiter zu Spieler B" : "Aufstellung",
				onBack: () => dispatch({ type: "back" }),
				onNext: () => dispatch({ type: "advance" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel flex flex-wrap items-end justify-between gap-4 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "display text-3xl",
					children: c.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						c.ability,
						" · ",
						c.abilityCost,
						" Energie"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm tabular-nums text-muted",
					children: [
						"Körper ",
						max.body,
						" · Energie max ",
						max.energy,
						" · Bruch ",
						max.bruch
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearRow, {
				title: "Waffe",
				selected: setup.weaponId,
				options: WEAPONS.map((w) => ({
					id: w.id,
					name: w.name,
					text: `Wert ${w.value} · Reichweite ${w.range} · ${w.text}`
				})),
				onPick: (id) => dispatch({
					type: "slot",
					slot: "weaponId",
					id
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearRow, {
				title: "Rüstung",
				selected: setup.armorId,
				options: ARMORS.map((w) => ({
					id: w.id,
					name: w.name,
					text: `Wert ${w.value} · Körper +${w.body} · ${w.text}`
				})),
				onPick: (id) => dispatch({
					type: "slot",
					slot: "armorId",
					id
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearRow, {
				title: "Werkzeug",
				selected: setup.toolId,
				options: GEAR.filter((g) => g.slot === "tool").map((w) => ({
					id: w.id,
					name: w.name,
					text: w.text
				})),
				onPick: (id) => dispatch({
					type: "slot",
					slot: "toolId",
					id
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearRow, {
				title: "Artefakt",
				selected: setup.artifactId,
				options: GEAR.filter((g) => g.slot === "artifact").map((w) => ({
					id: w.id,
					name: w.name,
					text: w.text
				})),
				onPick: (id) => dispatch({
					type: "slot",
					slot: "artifactId",
					id
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearRow, {
				title: "Verbrauch · zwei",
				selected: setup.items[0],
				also: setup.items[1],
				options: ITEMS.map((w) => ({
					id: w.id,
					name: w.name,
					text: w.text
				})),
				onPick: (id) => dispatch({
					type: "item",
					id
				})
			})
		]
	});
}
function Cover({ duel, dispatch }) {
	const who = duel.focus === "A" ? "Spieler A" : "Spieler B";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-6 px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Verdecktes Planen"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display text-5xl",
				children: who
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-muted",
				children: "Gib das Gerät weiter. Der andere Plan bleibt zu."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => dispatch({ type: "ready" }),
				children: "Ich bin bereit"
			})
		]
	});
}
function Ending({ duel, dispatch }) {
	const game = duel.game;
	const winner = game.winner ? CHARACTERS.find((c) => c.id === game.fighters[game.winner].characterId)?.name : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-xl flex-col justify-center gap-6 px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: ["Runde ", game.round]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display text-5xl",
				children: winner ? `${winner} siegt` : "Beide brechen"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted",
				children: [
					game.winReason === "Körper" && "Der Körper des Gegners ist auf 0.",
					game.winReason === "Echo" && "Alle drei Kern-Echos sind zerstört.",
					game.winReason === "Bruch" && "Das Bruchmaximum hat die letzte Runde beendet.",
					game.winReason === "Zeit" && "Die Zeit ist um."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex max-h-80 flex-col gap-2 overflow-auto text-sm text-muted",
				children: [...game.log].reverse().map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, `${index}-${line}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: () => dispatch({ type: "rematch" }),
						children: "Nochmal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => downloadText(`echo-bruch-${game.seed}.txt`, [...game.log].reverse().join("\n")),
						children: "Protokoll speichern"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => dispatch({ type: "ledger" }),
						children: "Alle Protokolle"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => dispatch({ type: "title" }),
						children: "Neues Duell"
					})
				]
			})
		]
	});
}
function Ledger({ onBack }) {
	const [logs, setLogs] = (0, import_react.useState)([]);
	const [open, setOpen] = (0, import_react.useState)(null);
	const [bilanz, setBilanz] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setLogs(readLogs());
		fetch("/bilanz.txt").then((response) => response.ok ? response.text() : "").then(setBilanz).catch(() => setBilanz(""));
	}, []);
	const current = logs.find((entry) => entry.id === open) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-3xl flex-col gap-5 px-4 py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Vollständig, nichts gekürzt"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-4xl",
					children: "Protokolle"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: onBack,
					children: "Zurück"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "btn",
					role: "button",
					href: "/protokoll.txt",
					download: "echo-bruch-protokoll.txt",
					children: "Simulationsprotokoll"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "btn",
					role: "button",
					href: "/bilanz.txt",
					download: "echo-bruch-bilanz.txt",
					children: "Bilanz"
				})]
			}),
			bilanz && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "panel max-h-80 overflow-auto whitespace-pre-wrap p-4 text-xs leading-relaxed text-muted",
				children: bilanz
			}),
			logs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Gespeicherte Duelle erscheinen hier, sobald eines endet. Bis zu sechzehn bleiben auf diesem Gerät."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: logs.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "panel w-full px-4 py-3 text-left text-sm",
					onClick: () => setOpen(entry.id === open ? null : entry.id),
					children: [entry.title, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-xs text-faint",
						children: [entry.lines.length, " Zeilen"]
					})]
				}) }, entry.id))
			}),
			current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel flex flex-col gap-3 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display text-2xl",
						children: current.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => downloadText(`echo-bruch-${current.id}.txt`, current.lines.join("\n")),
						children: "Diese Datei"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "flex max-h-[28rem] flex-col gap-1 overflow-auto text-sm text-muted",
					children: current.lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, `${current.id}-${index}`))
				})]
			})
		]
	});
}
function Battle({ duel, view, beat, dispatch }) {
	const legal = legalFields(duel, view);
	const selected = duel.screen === "deploy" ? duel.setup[duel.focus].field : duel.draft.targetField;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "display text-xl",
					children: "ECHO//BRUCH"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: duel.screen === "deploy" ? "Aufstellung" : beat ? beat.kicker : `Runde ${view.round} · Planen`
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn",
							"aria-label": duel.muted ? "Ton an" : "Ton aus",
							onClick: () => dispatch({ type: "mute" }),
							children: duel.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { size: 18 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn",
							"aria-label": "Regeln",
							onClick: () => dispatch({ type: "codex" }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { size: 18 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn",
							onClick: () => dispatch({ type: "title" }),
							children: "Menü"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhaseRail, {
				screen: duel.screen,
				beat
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid min-h-0 flex-1 grid-rows-[auto_minmax(0,1fr)] gap-2 px-3 lg:grid-cols-[16rem_minmax(0,1fr)_16rem] lg:grid-rows-1 lg:px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 lg:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FighterCard, {
							f: view.fighters.B,
							tag: duel.mode === "bot" ? "Bot" : "B",
							strip: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FighterCard, {
							f: view.fighters.A,
							tag: "Du",
							strip: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FighterCard, {
						f: view.fighters.A,
						tag: "Spieler A",
						className: "hidden overflow-auto lg:order-1 lg:block"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative min-h-0 lg:order-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `panel h-full overflow-hidden ${beat?.tone === "hit" ? "shake" : ""}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, {
								state: view,
								legal,
								selected,
								focus: beat?.focus ?? [],
								shake: false,
								onPick: duel.screen === "scene" ? void 0 : (field) => {
									if (duel.screen === "deploy") dispatch({
										type: "field",
										id: field
									});
									else if (legal.includes(field)) dispatch({
										type: "draft",
										plan: {
											...duel.draft,
											targetField: field
										}
									});
								}
							})
						}), beat && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, {
							beat,
							duel,
							dispatch
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FighterCard, {
						f: view.fighters.B,
						tag: duel.mode === "bot" ? "Bot" : "Spieler B",
						className: "hidden overflow-auto lg:order-3 lg:block"
					})
				]
			}),
			duel.screen === "deploy" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "flex flex-wrap items-center justify-between gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [duel.focus === "A" ? "Feld 2 oder 4." : "Feld 3 oder 5.", " Mindestens ein Feld Abstand ist durch die Startfelder schon gegeben."]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => dispatch({ type: "back" }),
						children: "Zurück"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: () => dispatch({ type: "advance" }),
						children: "Duell beginnen"
					})]
				})]
			}),
			duel.screen === "plan" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Planner, {
				duel,
				view,
				dispatch
			})
		]
	});
}
function Planner({ duel, view, dispatch }) {
	const f = view.fighters[duel.focus];
	const c = CHARACTERS.find((item) => item.id === f.characterId);
	const draft = duel.draft;
	const ready = preparePlan(view, duel.focus, draft);
	const abilityUsed = f.abilityRound === view.round;
	const canAbility = f.energy >= c.abilityCost && !abilityUsed;
	const predict = Object.entries(f.pattern).filter(([, n]) => n >= 3).map(([k]) => k);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "max-h-64 overflow-auto border-t border-line bg-surface px-3 py-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-5xl flex-col gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-baseline justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: duel.banner
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm tabular-nums text-muted",
						children: ["Aktionswert ", actionValue(f, ready)]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: ACTIONS.map((action) => {
						const Icon = ACTION_ICON[action.id];
						const on = draft.action === action.id && !draft.ability;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `btn h-auto flex-col gap-1 py-3 ${on ? "btn-on" : ""}`,
							onClick: () => dispatch({
								type: "draft",
								plan: withAction(draft, action.id, view, duel.focus)
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 18 }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: action.name }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-faint",
									children: [action.tempo > 0 ? `+${action.tempo}` : action.tempo, " Tempo"]
								})
							]
						}, action.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: "Energie"
						}),
						[
							0,
							1,
							2,
							3
						].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: draft.ability || n > f.energy,
							className: `btn min-w-11 ${draft.energy === n ? "btn-on" : ""}`,
							onClick: () => dispatch({
								type: "draft",
								plan: {
									...draft,
									energy: n,
									ability: false
								}
							}),
							children: n
						}, n)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: !canAbility,
							className: `btn ${draft.ability ? "btn-on" : ""}`,
							onClick: () => dispatch({
								type: "draft",
								plan: {
									...draft,
									ability: !draft.ability,
									action: c.abilityAction,
									energy: c.abilityCost
								}
							}),
							children: [
								c.ability,
								" · ",
								c.abilityCost
							]
						})
					]
				}),
				draft.action === "influence" && !draft.ability && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						["spur", "Spur legen"],
						["kern", "Kern brechen"],
						["weaken", "Echo schwächen"],
						["convert", "Umwandeln"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `btn ${draft.influence === id ? "btn-on" : ""}`,
						onClick: () => dispatch({
							type: "draft",
							plan: {
								...draft,
								influence: id
							}
						}),
						children: label
					}, id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 overflow-x-auto",
					children: [REACTIONS.map((reaction) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: `btn shrink-0 ${draft.reaction === reaction.id ? "btn-on" : ""}`,
						onClick: () => dispatch({
							type: "draft",
							plan: {
								...draft,
								reaction: draft.reaction === reaction.id ? null : reaction.id
							}
						}),
						children: [
							reaction.name,
							" · ",
							reaction.cost
						]
					}, reaction.id)), f.items.filter((item) => !item.spent).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `btn shrink-0 ${draft.itemId === item.id ? "btn-on" : ""}`,
						onClick: () => dispatch({
							type: "draft",
							plan: {
								...draft,
								itemId: draft.itemId === item.id ? null : item.id
							}
						}),
						children: ITEMS.find((entry) => entry.id === item.id)?.name
					}, item.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						f.ruleBreak && [
							"brace",
							"refund",
							"retarget"
						].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `btn ${draft.ruleBreak === id ? "btn-on" : ""}`,
							onClick: () => dispatch({
								type: "draft",
								plan: {
									...draft,
									ruleBreak: draft.ruleBreak === id ? null : id
								}
							}),
							children: id === "brace" ? "Regelbruch · 2 Bruch halten" : id === "refund" ? "Regelbruch · Stufe zurück" : "Regelbruch · Ziel ändern"
						}, id)),
						f.nadelReady && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `btn ${draft.zeitnadel ? "btn-on" : ""}`,
							onClick: () => dispatch({
								type: "draft",
								plan: {
									...draft,
									zeitnadel: !draft.zeitnadel
								}
							}),
							children: "Zeitnadel"
						}),
						(f.toolId === "rauch" || f.artifactId === "rauch") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `btn ${draft.mist ? "btn-on" : ""}`,
							onClick: () => dispatch({
								type: "draft",
								plan: {
									...draft,
									mist: !draft.mist
								}
							}),
							children: "Rauchkapsel"
						}),
						(f.toolId === "bruchstein" || f.artifactId === "bruchstein") && f.stoneRound !== view.round && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn",
							onClick: () => dispatch({ type: "stone" }),
							children: "Bruchstein"
						}),
						predict.map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `btn ${draft.prediction === kind ? "btn-on" : ""}`,
							onClick: () => dispatch({
								type: "draft",
								plan: {
									...draft,
									prediction: draft.prediction === kind ? null : kind
								}
							}),
							children: ["Vorhersage ", ACTIONS.find((a) => a.id === kind)?.name]
						}, kind))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: planHint(c, draft, ready, f, view)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sticky bottom-0 bg-surface pt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary w-full",
						onClick: () => {
							cue("idle", duel.muted);
							dispatch({ type: "lock" });
						},
						children: "Plan schließen"
					})
				})
			]
		})
	});
}
function Scene({ beat, duel, dispatch }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rise absolute inset-x-3 bottom-3 z-10 border border-line bg-bg p-4 sm:inset-x-6 lg:left-1/2 lg:w-[34rem] lg:-translate-x-1/2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: beat.kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display text-3xl",
					children: beat.title
				}), beat.dice != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "display text-5xl tabular-nums text-accent",
					children: beat.dice
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: beat.detail
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1",
					"aria-hidden": "true",
					children: duel.frames.map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `pip ${index === duel.frame ? "on-attack" : ""}` }, index))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn",
							onClick: () => dispatch({ type: "auto" }),
							"aria-label": duel.auto ? "Szenen anhalten" : "Szenen automatisch",
							children: duel.auto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { size: 16 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 16 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn",
							onClick: () => dispatch({ type: "step" }),
							children: "Weiter"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn",
							onClick: () => dispatch({ type: "skip" }),
							"aria-label": "Runde überspringen",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { size: 16 })
						})
					]
				})]
			})
		]
	});
}
function FighterCard({ f, tag, className = "", strip = false }) {
	const c = CHARACTERS.find((item) => item.id === f.characterId);
	const bits = [
		isOpen(f) ? "Offen" : "",
		f.collapse ? "Letzte Runde" : "",
		f.marked ? "Markiert" : "",
		f.flank ? "Durchgang" : "",
		...f.statuses.map((s) => s.kind === "guarded" ? "Geschützt" : s.kind === "bound" ? "Gebunden" : s.kind === "confused" ? "Verwirrt" : s.kind === "wounded" ? "Verletzt" : "")
	].filter(Boolean);
	if (strip) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: `panel min-w-0 flex-1 px-3 py-2 ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display truncate text-lg",
				children: c.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: tag
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-xs tabular-nums text-muted",
			children: [
				f.body,
				"/",
				f.bodyMax,
				" Körper · ",
				f.bruch,
				"/",
				f.bruchMax,
				" Bruch · ",
				f.energy,
				" Energie"
			]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: `panel px-3 py-3 ${className}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display text-2xl",
					children: c.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: tag
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Körper",
						value: f.body,
						max: f.bodyMax,
						tone: "body"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Bruch",
						value: f.bruch,
						max: f.bruchMax,
						tone: "bruch"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: "Energie"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex gap-1",
							children: Array.from({ length: f.energyMax }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `pip ${i < f.energy ? "on-guard" : ""}` }, i))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-3",
				children: f.cores.map((core, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex items-center gap-1",
					title: core.revealed ? `${core.points} Punkte` : "Verdeckt",
					children: [
						0,
						1,
						2
					].map((pip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `pip ${core.points > pip && core.revealed ? "on-influence" : ""}` }, pip))
				}, index))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-3",
				children: [
					"attack",
					"guard",
					"move",
					"influence"
				].map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex gap-1",
					title: ACTIONS.find((a) => a.id === kind)?.name,
					children: [
						0,
						1,
						2
					].map((pip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `pip ${f.pattern[kind] > pip ? `on-${kind}` : ""}` }, pip))
				}, kind))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 min-h-5 text-xs text-muted",
				children: bits.join(" · ") || "Stabil"
			}),
			f.echoes.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-faint",
				children: f.echoes.map((e) => `${ECHO_LABEL[e.kind]} ${e.charges}`).join(" · ")
			})
		]
	});
}
function Meter({ label, value, max, tone }) {
	const pct = max <= 0 ? 0 : Math.max(0, Math.min(100, value / max * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex justify-between text-xs text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "tabular-nums",
			children: [
				value,
				"/",
				max
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 rounded-full bg-raised",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `h-full rounded-full ${tone === "bruch" ? "bg-accent" : "bg-fg"}`,
			style: { width: `${pct}%` }
		})
	})] });
}
function StatLine({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center justify-between gap-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children: value
		})]
	});
}
function GearRow({ title, options, selected, also, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "mb-2 text-sm text-muted",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-2 lg:grid-cols-5",
		children: options.map((option) => {
			const on = option.id === selected || option.id === also;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: `panel p-3 text-left ${on ? "border-fg" : ""}`,
				onClick: () => onPick(option.id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-medium",
					children: option.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block text-sm text-muted line-clamp-3",
					children: option.text
				})]
			}, option.id);
		})
	})] });
}
function ScreenHead({ kicker, title, action, onBack, onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: kicker
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "display text-4xl",
			children: title
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn",
				onClick: onBack,
				children: "Zurück"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: onNext,
				children: action
			})]
		})]
	});
}
function PhaseRail({ screen, beat }) {
	const steps = [
		"Aktualisieren",
		"Planen",
		"Aufdecken",
		"Handeln",
		"Ende"
	];
	const current = screen === "deploy" ? -1 : screen === "plan" ? 1 : beat?.kicker.includes("Aufdecken") ? 2 : beat?.kicker.includes("Ende") || beat?.kicker.includes("Entscheidung") ? 4 : 3;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-3 overflow-x-auto px-4 pb-2 text-xs text-faint",
		children: steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: index === current ? "text-fg" : "",
			children: step
		}, step))
	});
}
function Sigil({ id }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 48 48",
		className: "h-10 w-10 text-soft",
		"aria-hidden": "true",
		children: [
			id === "brecher" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 36 L24 8 L40 36 Z",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			id === "laeuferin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 32 C16 8 32 8 40 32",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			id === "archivar" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "10",
				y: "10",
				width: "28",
				height: "28",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			id === "waechter" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 16 H40 V28 C40 36 32 40 24 40 C16 40 8 36 8 28 Z",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			id === "jaeger" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "24",
				cy: "24",
				r: "12",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			})
		]
	});
}
function Codex({ onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-20 flex items-end justify-center bg-bg/80 p-3 sm:items-center",
		role: "dialog",
		"aria-label": "Regelreferenz",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel max-h-[80dvh] w-full max-w-lg overflow-auto p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display text-3xl",
					children: "Regelreferenz"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: onClose,
					children: "Schließen"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-3 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Sieg durch Körper 0, durch drei zerstörte Kern-Echos, oder wenn das Bruchmaximum die letzte Runde beendet." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Jede Runde: Energie +2, verdeckt planen, aufdecken, höherer Aktionswert zuerst, dann Echos und die Schlussprüfung." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Angriff trifft, wenn Würfel plus Angriffswert mindestens die Verteidigung erreicht. Eine 6 verdoppelt den Endschaden." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Schutz mildert den nächsten Treffer. Bewegung folgt den Verbindungen. Einfluss legt Spuren, schwächt Echos oder bricht Kerne." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Dieselbe Grundaktion zweimal hintereinander gibt dem Gegner einen Musterpunkt. Bei drei Punkten einer Farbe darfst du vorhersagen." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Ein Regelbruch pro Kampf. Ein Item und eine Reaktion pro Runde." })
				]
			})]
		})
	});
}
function shownState(duel, beat) {
	if (duel.screen === "scene") return beat?.state ?? duel.game;
	if (duel.screen === "deploy") {
		const b = duel.mode === "bot" ? botSetup(duel.setup.A, duel.difficulty) : { ...duel.setup.B };
		if (duel.mode === "bot") b.field = duel.setup.A.field === 4 ? 3 : 5;
		return createGame(duel.setup.A, b, 1);
	}
	return duel.game;
}
function legalFields(duel, view) {
	if (duel.screen === "deploy") return STARTS[duel.focus];
	if (duel.screen !== "plan") return [];
	const f = view.fighters[duel.focus];
	const foe = view.fighters[other(duel.focus)];
	const stats = liveStats(f);
	if (duel.draft.action === "move") return reachable(f.field, moveSteps(f, duel.draft.energy, duel.draft.ability), foe.field);
	if (duel.draft.action === "attack") {
		const range = duel.draft.ability && f.characterId === "brecher" ? 1 : stats.range;
		if (f.weaponId === "bogen" && f.statuses.some((s) => s.kind === "bound")) return [];
		return distance(f.field, foe.field) <= range ? [foe.field] : [];
	}
	if (duel.draft.action === "influence" && duel.draft.influence === "kern") return [foe.field];
	return [];
}
function withAction(draft, action, game, side) {
	const f = game.fighters[side];
	const foe = game.fighters[other(side)];
	const next = {
		...draft,
		action,
		ability: false
	};
	if (action === "attack") next.targetField = foe.field;
	if (action === "guard") next.targetField = f.field;
	if (action === "move") {
		const fields = reachable(f.field, moveSteps(f, next.energy, false), foe.field);
		next.targetField = fields.includes(draft.targetField ?? -1) ? draft.targetField : fields[0] ?? null;
	}
	if (action === "influence") next.targetField = foe.field;
	return next;
}
function planHint(c, draft, ready, f, view) {
	if (draft.ability) return c.abilityText;
	if (draft.action === "attack" && ready.action !== "attack") return "Nicht in Reichweite. Der Plan wird zu Schutz.";
	if (draft.action === "move") return ready.targetField ? `Ziel Feld ${ready.targetField}. Besetzte Felder bleiben zu.` : "Kein freies Feld in Reichweite.";
	if (draft.action === "guard") return `Nächster Treffer −${draft.energy >= 1 ? 4 : 3}${draft.energy >= 3 ? ". Dazu ein Schutz-Echo." : "."}`;
	if (draft.influence === "kern") return `Kern-Echos in Reichweite ${distance(f.field, view.fighters[other(f.side)].field) <= 3 ? "ja" : "nein"}. Kostet mindestens 1 Energie.`;
	return "Einfluss legt eine Spur oder verändert, was schon auf dem Feld liegt.";
}
function Home() {
	const [full, setFull] = (0, import_react.useState)(false);
	if (full) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, { onBasis: () => setFull(false) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BasisApp, { onFull: () => setFull(true) });
}
//#endregion
export { Home as component };
