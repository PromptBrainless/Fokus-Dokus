import type { Form } from "./karte";
import type { Zone } from "./regeln";

export type CharakterId = "brecher" | "laeuferin" | "archivar" | "waechter" | "jaeger";

export interface Charakter {
  id: CharakterId;
  name: string;
  zeile: string;
  ws: number;
  bs: number;
  staerke: number;
  widerstand: number;
  ausweichen: number;
  wunden: number;
  bewegung: number;
  form: Form;
  reichweite: number;
  waffe: number;
  ruestung: Record<Zone, number>;
}

const leicht: Record<Zone, number> = {
  kopf: 0,
  "arm-links": 1,
  "arm-rechts": 1,
  koerper: 1,
  "bein-links": 1,
  "bein-rechts": 1,
};

const platte: Record<Zone, number> = {
  kopf: 2,
  "arm-links": 3,
  "arm-rechts": 3,
  koerper: 4,
  "bein-links": 2,
  "bein-rechts": 2,
};

export const CHARAKTERE: Charakter[] = [
  {
    id: "brecher",
    name: "Brecher",
    zeile: "Nah, hart, langsam.",
    ws: 55,
    bs: 25,
    staerke: 5,
    widerstand: 4,
    ausweichen: 25,
    wunden: 16,
    bewegung: 3,
    form: "nah",
    reichweite: 1,
    waffe: 6,
    ruestung: { ...platte, koerper: 3, kopf: 1 },
  },
  {
    id: "laeuferin",
    name: "Läuferin",
    zeile: "Weit gehen, dem Schlag ausweichen.",
    ws: 48,
    bs: 30,
    staerke: 4,
    widerstand: 3,
    ausweichen: 60,
    wunden: 12,
    bewegung: 5,
    form: "nah",
    reichweite: 1,
    waffe: 4,
    ruestung: leicht,
  },
  {
    id: "archivar",
    name: "Archivar",
    zeile: "Bogen über Bau. Einmal die Zone wählen.",
    ws: 40,
    bs: 52,
    staerke: 3,
    widerstand: 3,
    ausweichen: 35,
    wunden: 13,
    bewegung: 4,
    form: "bogen",
    reichweite: 6,
    waffe: 5,
    ruestung: leicht,
  },
  {
    id: "waechter",
    name: "Wächter",
    zeile: "Parieren und Rüstung.",
    ws: 48,
    bs: 25,
    staerke: 4,
    widerstand: 5,
    ausweichen: 30,
    wunden: 18,
    bewegung: 3,
    form: "nah",
    reichweite: 1,
    waffe: 4,
    ruestung: platte,
  },
  {
    id: "jaeger",
    name: "Jäger",
    zeile: "Schuss bis zum ersten Hindernis.",
    ws: 35,
    bs: 58,
    staerke: 3,
    widerstand: 3,
    ausweichen: 42,
    wunden: 13,
    bewegung: 4,
    form: "schuss",
    reichweite: 6,
    waffe: 5,
    ruestung: leicht,
  },
];

export function charakter(id: CharakterId): Charakter {
  return CHARAKTERE.find((item) => item.id === id)!;
}
