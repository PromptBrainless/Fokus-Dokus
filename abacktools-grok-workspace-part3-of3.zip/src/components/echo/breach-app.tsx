import { useEffect, useState } from "react";
import { AKTIONEN, FOLGE } from "@/game/w100/aktionen";
import { CHARAKTERE, charakter, type CharakterId } from "@/game/w100/charaktere";
import { BREITE, gleich, istBau, vonIndex, type Feld } from "@/game/w100/karte";
import { abwehrWaehlen, ankuendigen, bedroht, bewegen, bot, imMuster, kann, laufFelder, neuerKampf, passen, schlagFelder, type Kampf, type Seite } from "@/game/w100/kampf";
import { ZONE_NAME, type Zone } from "@/game/w100/regeln";
import { SpielerBlick } from "./spieler-blick";

const ZONEN: Zone[] = ["kopf", "arm-links", "arm-rechts", "koerper", "bein-links", "bein-rechts"];

export function BreachApp({ onArchiv }: { onArchiv: () => void }) {
  const [kampf, setKampf] = useState<Kampf | null>(null);
  const [a, setA] = useState<CharakterId>("brecher");
  const [b, setB] = useState<CharakterId>("jaeger");
  const [modus, setModus] = useState<"bot" | "gegen">("bot");
  const [wahl, setWahl] = useState<"bewegen" | "schlagen" | null>(null);
  const [zone, setZone] = useState<Zone>("koerper");

  useEffect(() => {
    if (!kampf || kampf.vorbei || modus !== "bot" || kampf.amZug !== "B") return;
    const timer = window.setTimeout(() => setKampf(bot(kampf)), 1500);
    return () => window.clearTimeout(timer);
  }, [kampf, modus]);

  if (!kampf) {
    return (
      <main className="mx-auto flex min-h-dvh max-w-3xl flex-col gap-6 px-4 py-8">
        <p className="text-xs uppercase tracking-wide text-muted">Neues Kampfsystem</p>
        <h1 className="display text-4xl">Gitter und W100</h1>
        <p className="text-sm text-muted">
          Acht mal acht Felder. Schlagen würfelt sofort mit einem W100. Die Zone ist der umgedrehte Wurf. Die Szene zeigt nur, was du siehst.
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          <Wahl label="Du" value={a} onChange={setA} />
          <Wahl label="Gegenüber" value={b} onChange={setB} />
        </div>
        <div className="flex gap-2">
          <button type="button" className={`btn ${modus === "bot" ? "btn-on" : ""}`} onClick={() => setModus("bot")}>
            Gegen den Bot
          </button>
          <button type="button" className={`btn ${modus === "gegen" ? "btn-on" : ""}`} onClick={() => setModus("gegen")}>
            Zu zweit
          </button>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setKampf(neuerKampf(a, b))}>
          Kampf beginnen
        </button>
        <button type="button" className="btn" onClick={onArchiv}>
          Altes System
        </button>
      </main>
    );
  }

  const seite = kampf.amZug;
  const ich = kampf.kaempfer[seite];
  const duBist = modus === "bot" && seite === "B";
  const laufen = wahl === "bewegen" ? laufFelder(kampf, seite) : [];
  const zielen = schlagFelder(kampf, seite);
  const c = charakter(ich.id);

  function waehleFeld(feld: Feld) {
    if (duBist || kampf!.vorbei) return;
    if (wahl === "bewegen") {
      setKampf(bewegen(kampf!, feld));
      setWahl(null);
    }
  }

  const auge: Seite = modus === "bot" ? "A" : seite;
  const gegnerId = kampf.kaempfer[auge === "A" ? "B" : "A"].id;

  return (
    <main className="mx-auto flex min-h-dvh max-w-6xl flex-col gap-4 px-3 py-4">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-wide text-muted">Am Zug</p>
          <h1 className="display text-3xl">{ich.name}</h1>
        </div>
        <div className="flex gap-2">
          <button type="button" className="btn" onClick={() => setKampf(null)}>
            Neu
          </button>
          <button type="button" className="btn" onClick={onArchiv}>
            Archiv
          </button>
        </div>
      </header>
      <SpielerBlick blick={kampf.blick} gegner={gegnerId} />
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_20rem]">
        <div>
          <div className="grid grid-cols-8 gap-1">
            {Array.from({ length: BREITE * BREITE }, (_, id) => {
              const feld = vonIndex(id);
              const aDa = gleich(kampf.kaempfer.A.feld, feld);
              const bDa = gleich(kampf.kaempfer.B.feld, feld);
              const bau = istBau(feld);
              const ziel = imMuster(kampf, seite, feld);
              const lauf = laufen.some((item) => gleich(item, feld));
              const inForm = zielen.some((item) => gleich(item, feld));
              return (
                <button
                  key={id}
                  type="button"
                  disabled={!lauf}
                  onClick={() => waehleFeld(feld)}
                  className={`relative aspect-square rounded-md border text-xs ${bau ? "border-transparent bg-raised" : "border-line bg-surface"} ${ziel ? "ring-2 ring-accent" : ""} ${lauf ? "ring-2 ring-soft" : ""} ${inForm && !bau ? "outline outline-1 outline-white/30" : ""}`}
                >
                  {aDa && <span className="display text-lg">A</span>}
                  {bDa && <span className="display text-lg text-accent">B</span>}
                  {bau && !aDa && !bDa && <span className="text-[10px] text-faint">Bau</span>}
                </button>
              );
            })}
          </div>
          <p className="mt-2 text-xs text-muted">
            {bedroht(kampf, seite)
              ? "Du stehst in der Form des anderen. Ausweichen oder Parieren gilt für den nächsten Schlag."
              : "Die umrandeten Felder sind die Form des Gegners. Schlagen würfelt sofort, wenn du ihn darin hast."}
          </p>
        </div>
        <aside className="flex flex-col gap-3">
          <Karte seite="A" kampf={kampf} />
          <Karte seite="B" kampf={kampf} />
          <p className="text-xs text-muted">Aktionen: {kampf.punkte}. {c.zeile}</p>
          {ich.zoneWahl && (
            <label className="text-xs text-muted">
              Zone festlegen
              <select className="btn mt-1 w-full" value={zone} onChange={(event) => setZone(event.target.value as Zone)}>
                {ZONEN.map((item) => (
                  <option key={item} value={item}>
                    {ZONE_NAME[item]}
                  </option>
                ))}
              </select>
            </label>
          )}
          <div className="grid grid-cols-2 gap-2">
            {AKTIONEN.map((aktion) => (
              <button
                key={aktion.id}
                type="button"
                disabled={duBist || !kann(kampf, aktion.id)}
                className={`btn h-auto flex-col items-start py-2 text-left ${wahl === aktion.id ? "btn-on" : ""}`}
                onClick={() => {
                  if (aktion.id === "bewegen") setWahl(wahl === "bewegen" ? null : "bewegen");
                  if (aktion.id === "schlagen") {
                    setKampf(ankuendigen(kampf, ich.zoneWahl ? zone : null));
                    setWahl(null);
                  }
                  if (aktion.id === "parieren" || aktion.id === "ausweichen") setKampf(abwehrWaehlen(kampf, aktion.id));
                  if (aktion.id === "passen") setKampf(passen(kampf));
                }}
              >
                <span>{aktion.name}</span>
                <span className="text-xs text-faint">{aktion.text}</span>
              </button>
            ))}
          </div>
          {kampf.vorbei && <p className="display text-2xl">{kampf.sieger ? `${kampf.kaempfer[kampf.sieger].name} steht.` : "Unentschieden"}</p>}
        </aside>
      </div>
      <section className="panel max-h-48 overflow-auto p-3">
        <p className="text-[10px] uppercase tracking-wide text-faint">{FOLGE[Math.min(4, 4 - kampf.punkte)]}</p>
        <ol className="mt-2 flex flex-col gap-1 text-sm text-muted">
          {kampf.log.slice(0, 8).map((zeile, i) => (
            <li key={`${i}-${zeile}`}>{zeile}</li>
          ))}
        </ol>
      </section>
    </main>
  );
}

function Wahl({ label, value, onChange }: { label: string; value: CharakterId; onChange: (id: CharakterId) => void }) {
  return (
    <label className="text-sm">
      {label}
      <select className="btn mt-1 w-full" value={value} onChange={(event) => onChange(event.target.value as CharakterId)}>
        {CHARAKTERE.map((item) => (
          <option key={item.id} value={item.id}>
            {item.name} · {item.zeile}
          </option>
        ))}
      </select>
    </label>
  );
}

function Karte({ seite, kampf }: { seite: Seite; kampf: Kampf }) {
  const k = kampf.kaempfer[seite];
  const c = charakter(k.id);
  return (
    <article className={`panel p-3 ${kampf.amZug === seite ? "ring-1 ring-white/40" : ""}`}>
      <div className="flex items-baseline justify-between">
        <h2 className="display text-xl">{k.name}</h2>
        <p className="text-xs text-muted">{seite}</p>
      </div>
      <p className="text-xs tabular-nums text-muted">
        {k.wunden}/{k.wundenMax} Wunden · Vorteil {k.vorteil} · {c.form === "nah" ? `WS ${c.ws}` : `BS ${c.bs}`}
      </p>
      <p className="text-xs text-faint">
        {k.abwehr !== "keine" ? k.abwehr : "keine Abwehr"}
        {k.liegt ? " · liegt" : ""}
        {k.blutung ? " · blutet" : ""}
      </p>
    </article>
  );
}
