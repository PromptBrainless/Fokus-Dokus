//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-aVhXkPth.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D3nnpXtM.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D3nnpXtM.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-XX22wbc1.js"]
	}
} });
//#endregion
export { tsrStartManifest };
